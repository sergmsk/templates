import type { ZodErrorMap } from 'zod';
import z from 'zod';

import { t } from '~/utils';
import { EMPTY_FIELD_ERROR_MESSAGE } from '~/shared/validation';
import { parseFloatNumber } from '~/shared/utils';

type RawCreateParams = {
  errorMap?: ZodErrorMap;
  invalid_type_error?: string;
  required_error?: string;
  description?: string;
};

/** string date **/
const datePreprocess = (value) => {
  if (!value) {
    return undefined;
  }

  if (typeof value == 'string' || value instanceof Date) return new Date(value);

  return value;
};

export const dateSchema = (params?: RawCreateParams) =>
  z.preprocess(datePreprocess, z.date(params));

export const dateOptionalSchema = (params?: RawCreateParams) =>
  z.preprocess(datePreprocess, z.date(params).optional());

/** string number **/
const NUMBER_TYPE_ERROR = {
  invalid_type_error: t('common.validation.invalidTypeNumber'),
};

const NUMBER_REQUIRED_ERROR = {
  required_error: EMPTY_FIELD_ERROR_MESSAGE,
};

const numberPreprocess = (value) => {
  if (!value) {
    return undefined;
  }

  const number = parseFloatNumber(value);

  if (!Number.isNaN(number) && number == value.toString().replace(',', '.')) {
    return number;
  }

  return value;
};

export const numberSchema = (params?: RawCreateParams) =>
  z.preprocess(
    numberPreprocess,
    z.number({ ...NUMBER_TYPE_ERROR, ...NUMBER_REQUIRED_ERROR, ...params }),
  );

export const numberOptionalSchema = (params?: RawCreateParams) =>
  z.preprocess(numberPreprocess, z.number({ ...NUMBER_TYPE_ERROR, ...params }).optional());

export const numberNullishSchema = (params?: RawCreateParams) =>
  z.preprocess(numberPreprocess, z.number({ ...NUMBER_TYPE_ERROR, ...params }).nullish());

export const numberIntNonnegativeOptionalSchema = (params?: RawCreateParams) =>
  z.preprocess(
    numberPreprocess,
    z
      .number({ ...NUMBER_TYPE_ERROR, ...params })
      .nonnegative({ message: t('common.validation.nonnegativeNumber') })
      .optional(),
  );

export const numberIntegerNonnegativeOptionalSchema = (params?: RawCreateParams) =>
  z.preprocess(
    numberPreprocess,
    z
      .number({ ...NUMBER_TYPE_ERROR, ...params })
      .nonnegative({ message: t('common.validation.nonnegativeNumber') })
      .int({ message: t('common.validation.mustBeInteger') })
      .optional(),
  );

export const numberIntNonnegativeWithMaxOptionalSchema = (max: number, params?: RawCreateParams) =>
  z.preprocess(
    numberPreprocess,
    z
      .number({ ...NUMBER_TYPE_ERROR, ...params })
      .nonnegative({ message: t('common.validation.nonnegativeNumber') })
      .max(max, t('common.validation.lessOrEqualMaxNumber', { max }))
      .optional(),
  );

export const numberIntegerNonnegativeWithMaxOptionalSchema = (
  max: number,
  params?: RawCreateParams,
) =>
  z.preprocess(
    numberPreprocess,
    z
      .number({ ...NUMBER_TYPE_ERROR, ...params })
      .nonnegative({ message: t('common.validation.nonnegativeNumber') })
      .max(max, t('common.validation.lessOrEqualMaxNumber', { max }))
      .int({ message: t('common.validation.mustBeInteger') })
      .optional(),
  );

export const stringRequiredSchema = z
  .string({
    required_error: EMPTY_FIELD_ERROR_MESSAGE,
    invalid_type_error: EMPTY_FIELD_ERROR_MESSAGE,
  })
  .min(1, EMPTY_FIELD_ERROR_MESSAGE);
