import { t } from '~/utils';

export const LETTERS_EN = 'a-zA-Z';
export const LETTERS_RU = 'а-яА-ЯёЁ';

export const EMPTY_FIELD_ERROR_MESSAGE = t('common.validation.empty');

export const SAME_LANGUAGE_REGEXP = new RegExp(`^([^${LETTERS_RU}]*|[^${LETTERS_EN}]*)$`);
export const SAME_LANGUAGE_ERROR_MESSAGE = t('common.validation.sameLanguage');

const NAME_WORDS = `[${LETTERS_EN}${LETTERS_RU}]`;
const NAME_PREFIX = `(${NAME_WORDS}+)`;
const NAME_DELIMETR = `(-| )`;
const NAME_POSTFIX = `((${NAME_DELIMETR}${NAME_PREFIX})*?)`;
const NAME_REPEAT = `(${NAME_PREFIX}${NAME_POSTFIX})`;
export const NAME_REGEXP = new RegExp(`^${NAME_REPEAT}?$`);
export const NAME_ERROR_MESSAGE = t('common.validation.onlyLetters');

export const PHONE_REGEXP = /^[-+\d() ]*$/;
export const PHONE_ERROR_MESSAGE = t('common.validation.wrongCharacter', {
  characters: '0-9, "-", " ", "+", "(", ")"',
});

export const FIRST_CHARECTER_REGEXP = new RegExp(`^${NAME_WORDS}`);
export const FIRST_CHARECTER_MESSAGE = t('common.validation.firstCharacterLetter');

export const URL_REGEXP =
  /^((http|https|ftp):\/\/)?(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)|(([а-яА-ЯёЁ0-9][а-яА-ЯёЁ0-9_-]*)(\.[а-яА-ЯёЁ0-9][а-яА-ЯёЁ0-9_-]*)+)/i;
export const URL_ERROR_MESSAGE = t('common.validation.wrongURL');

export const IP_REGEXP = new RegExp('([0-9]{1,3}[.]){3}[0-9]{1,3}');
export const IP_ERROR_MESSAGE = t('common.validation.wrongIP');

export const PHONE_FIRST_PLUS_REGEXP = /^\+?[^+]*$/;
export const PHONE_FIRST_PLUS_ERROR_MESSAGE = t('common.validation.phoneFirstPlus');

export const EMAIL_REGEXP =
  /^(([^<>()\\[\]\\.,;:\s@"]+(\.[^<>()\\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export const EMAIL_ERROR_MESSAGE = t('common.validation.email');
export const EMAIL_NOT_CYRILLIC_REGEXP = new RegExp(`^[^${LETTERS_RU}]*$`);
export const EMAIL_NOT_CYRILLIC_ERROR_MESSAGE = t('common.validation.cyrillicEmail');

export const PHONE_NUMBER_REGEXP = /(^\+7\s?\(?$)|(^\+7\s?\(?\d\d\d\)?\s?\d\d\d\s?\d\d\s?\d\d$)/;
export const PHONE_NUMBER_ERROR_MESSAGE = t('common.validation.phoneNumber');

export const HASH_REGEXP = new RegExp('^[A-Za-z0-9]+$');
export const HASH_ERROR_MESSAGE = t('common.validation.hash');

export const FILE_TYPE_MESSAGE = t('common.validation.file.expectedFile');
export const FILE_MAX_SIZE_MESSAGE = t('common.validation.file.maxSize');
export const FILE_MAX_AMOUNT_MESSAGE = t('common.validation.file.maxAmount');
