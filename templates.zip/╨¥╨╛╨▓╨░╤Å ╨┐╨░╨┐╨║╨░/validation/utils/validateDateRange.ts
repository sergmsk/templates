import z from 'zod';
import dayjs from 'dayjs';
import { t } from '~/utils';

export const validateDateRange = (
  ctx: z.RefinementCtx,
  {
    from,
    to,
    fromPath,
    toPath,
  }: { from?: Date | null; to?: Date | null; fromPath: string[]; toPath: string[] },
): void => {
  if (from || to) {
    if (from && to && dayjs(from).isSame(dayjs(to))) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: fromPath,
        message: t('common.validation.fromDateEqualsToDate'),
      });
    }

    if (from && to && dayjs(from).isAfter(dayjs(to))) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: fromPath,
        message: t('common.validation.fromDateGreaterThanToDate'),
      });
    }

    if (from && !to) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: toPath,
        message: t('common.validation.toDateRequired'),
      });
    }

    if (!from && to) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: fromPath,
        message: t('common.validation.fromDateRequired'),
      });
    }
  }
};
