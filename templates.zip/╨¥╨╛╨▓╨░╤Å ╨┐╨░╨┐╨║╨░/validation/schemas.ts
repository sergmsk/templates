import z from 'zod';
import { zfd } from 'zod-form-data';
import {
  numberIntegerNonnegativeWithMaxOptionalSchema,
  numberIntNonnegativeWithMaxOptionalSchema,
} from '~/shared/schemas';
import { t } from '~/utils/i18next';

export const numberOptionalSchema = zfd.numeric(
  z.number({ invalid_type_error: t('common.validation.invalidTypeNumber') }).optional(),
);

export const numberIntNonnegativeWithMaxBillionOptionalSchema =
  numberIntNonnegativeWithMaxOptionalSchema(Math.pow(10, 9));

export const numberIntegerNonnegativeWithMaxBillionOptionalSchema =
  numberIntegerNonnegativeWithMaxOptionalSchema(Math.pow(10, 9));
