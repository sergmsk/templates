import * as React from 'react';
import { useMatches } from '@remix-run/react';

export const useManual = () => {
  const [rootData] = useMatches();

  const DOCS_URL = rootData?.data?.ENV.DOCS_URL as string;
  const ENV = rootData?.data?.ENV;

  const links = React.useMemo(
    () => ({
      DOCS_URL,
      USER_MANUAL_URL: `${DOCS_URL}${ENV?.USER_MANUAL_URL}`,
      ADMIN_MANUAL_URL: `${DOCS_URL}${ENV?.ADMIN_MANUAL_URL}`,
      RELEASE_NOTES_URL: `${DOCS_URL}${ENV?.RELEASE_NOTES_URL}`,
      QUICK_START_URL: `${DOCS_URL}${ENV?.QUICK_START_URL}`,
      EN_USER_MANUAL_URL: `${DOCS_URL}en/${ENV?.USER_MANUAL_URL}`,
      EN_USER_MANUAL_BASE_URL: `${DOCS_URL}en/${ENV?.USER_MANUAL_BASE_URL}`,
      USER_MANUAL_BASE_URL: `${DOCS_URL}${ENV?.USER_MANUAL_BASE_URL}`,
    }),
    [DOCS_URL, ENV],
  );

  return links;
};
