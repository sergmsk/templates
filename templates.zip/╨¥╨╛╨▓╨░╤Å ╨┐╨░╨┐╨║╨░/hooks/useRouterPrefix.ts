import { useMainRouteData } from './useMainRouteData';

export const useRouterPrefix = () => {
  return useMainRouteData()?.routerPrefix ?? '';
};
