import { useStore } from '@pb/store';
import { useCallback } from 'react';

export function useObjectStore<T>(key: string, defaultValue?: T) {
  const [storeValue, setStoreValue] = useStore<T>(key, defaultValue);

  const set = useCallback((value: Partial<T>) => {
    setStoreValue((prev) => ({ ...prev, ...value }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return [storeValue, set] as const;
}
