import { useMemo } from 'react';
import { partyMentionsBlockchainsDictionarySchema } from '~/shared/api/snippetdispatcher';
import { useRouteData } from '~/shared/hooks';
const ROUTE_ID = 'routes/__main';

export const useParticipantMentionsBlockchain = () => {
  const routeData = useRouteData(ROUTE_ID, partyMentionsBlockchainsDictionarySchema);

  return useMemo(
    () =>
      routeData?.dicts.participantMentionsBlockchains.map((item) => ({
        name: item.name,
        value: item.name,
      })),
    [routeData],
  );
};
