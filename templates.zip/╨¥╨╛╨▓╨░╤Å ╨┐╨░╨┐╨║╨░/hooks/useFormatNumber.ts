import { useMemo } from 'react';
import type { TUseFormatNumberModelResponse } from './useFormatNumberModel';
import { useFormatNumberModel } from './useFormatNumberModel';

type TUseFormatNumberResponse = {
  formatNumber: TUseFormatNumberModelResponse;
};

/**
 * Hook returns function for NUMBER with preset options.
 * You can override them, or add other options
 *
 * @param defaultOptions
 */
export const useFormatNumber = (
  defaultOptions?: Intl.NumberFormatOptions,
): TUseFormatNumberResponse => {
  const options = useMemo(
    () => ({
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
      ...defaultOptions,
    }),
    [defaultOptions],
  );
  const formatNumber = useFormatNumberModel(options);

  return {
    formatNumber,
  };
};
