import { useLocation } from '@remix-run/react';

export const useDenseLayout = () => {
  const location = useLocation();

  const isGraphPage = /^\/graphs\/\d+\//.test(location.pathname);

  return isGraphPage;
};
