import { useMainRouteData } from '~/shared/hooks/useMainRouteData';
import type { TKeycloakUser } from '~/types';

export const useUserProfile = (): TKeycloakUser | null => {
  const mainRouteData = useMainRouteData();

  return mainRouteData?.userProfile ?? null;
};
