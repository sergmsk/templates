import { useCallback, useMemo } from 'react';
import { EChainId, ETxModel } from '~/shared/enums';
import { useRouteData } from '~/shared/hooks/useRouteData';
import { getDictionaryBlockchainSchema } from '~/shared/api/aggregation';
import { EBlockchainCode } from '~/shared/chain';
const ROUTE_ID = 'routes/__main';

export type TBlockchainItem = {
  decimals: number;
  id: number;
  value: number;
  code: string;
  name: string;
  lowerCaseCode: EBlockchainCode;
  txModel: ETxModel;
  iconHref?: string;
};

const DEFAULT_BLOCKCHAIN: TBlockchainItem = {
  decimals: 0,
  id: 0,
  value: 0,
  code: '',
  name: '',
  lowerCaseCode: EBlockchainCode.Btc,
  txModel: ETxModel.Utxo,
};

const BLOCKCHAIN_DECIMALS_MAP: Map<EChainId, number> = new Map([
  [EChainId.BitcoinCash, 0],
  [EChainId.Btc, 0],
  [EChainId.Eth, 18],
  [EChainId.Litecoin, 0],
  [EChainId.Omni, 0],
  [EChainId.Tron, 6],
  [EChainId.BitcoinGold, 0],
  [EChainId.Dogecoin, 0],
]);

export const useBlockchainDictionary = () => {
  const routeData = useRouteData(ROUTE_ID, getDictionaryBlockchainSchema);

  const blockchains: TBlockchainItem[] = useMemo(
    () =>
      routeData?.dicts?.blockchains?.content.map((item) => ({
        ...item,
        lowerCaseCode: item.code.toLowerCase() as EBlockchainCode,
        value: item.id,
        decimals: BLOCKCHAIN_DECIMALS_MAP.get(item.id) ?? 0,
        txModel: item.txModel as ETxModel,
      })) || [],
    [routeData?.dicts?.blockchains?.content],
  );

  const getBlockchainByCode = useCallback(
    (code: string): TBlockchainItem => {
      return blockchains.find((item) => item.code === code) || DEFAULT_BLOCKCHAIN;
    },
    [blockchains],
  );

  const getBlockchainById = useCallback(
    (id: number): TBlockchainItem => {
      return blockchains.find((item) => item.id == id) || DEFAULT_BLOCKCHAIN;
    },
    [blockchains],
  );

  return { blockchains, getBlockchainByCode, getBlockchainById };
};
