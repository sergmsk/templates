import { useActionData } from '@remix-run/react';
import { useTranslatedData } from '~/shared/hooks/index';

export const useTranslatedActionData = <Data>(): Data | null => {
  const actionData = useActionData<string>();
  const translatedData = useTranslatedData<Data>(actionData);

  return translatedData;
};
