import { GROUPS } from '~/shared/constants';
import { useUserProfile } from './useUserProfile';

export const useProfileGroup = (): string => {
  const userProfile = useUserProfile();

  if (!userProfile) {
    return '';
  }

  const group = userProfile.groups.find((name) => name in GROUPS);

  if (!group) {
    return '';
  }

  return GROUPS[group];
};
