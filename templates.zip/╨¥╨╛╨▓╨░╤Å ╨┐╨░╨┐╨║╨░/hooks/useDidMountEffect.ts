import * as React from 'react';

type TUseDidMountEffect<T = () => unknown> = (cb?: T) => {
  didMount: boolean;
};

export const useDidMountEffect: TUseDidMountEffect = (cb) => {
  const didMount = React.useRef(false);

  React.useEffect(() => {
    if (didMount.current && cb) {
      cb();
    } else {
      didMount.current = true;
    }
  }, [cb]);

  return {
    didMount: didMount.current,
  };
};
