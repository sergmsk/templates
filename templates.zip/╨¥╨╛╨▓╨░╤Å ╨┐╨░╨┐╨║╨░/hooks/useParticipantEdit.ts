import { useCallback, useEffect, useMemo, useState } from 'react';
import type { SetStateAction, Dispatch } from 'react';
import type { FieldValues } from 'react-hook-form';
import { useNavigationConfirm } from '~/shared/hooks';
import type { TUseInitFormReturn } from '../form';

type TParticipantEditState = {
  isOpen: boolean;
  onUnblockTransition: () => void;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
};

type TUseParticipantEdit = <T extends FieldValues>(
  form: TUseInitFormReturn<T>,
) => TParticipantEditState;

export const useParticipantEdit: TUseParticipantEdit = (form) => {
  const [hasChanges, setHasChanges] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const isSubmitting = form.methods.formState.isSubmitting;
  const { formState } = form.methods;
  const isDirty = formState.isDirty;

  const { showPrompt, setShowPrompt, unblock } = useNavigationConfirm(hasChanges && !hasSubmitted);

  const handleUnblockTransition = useCallback(() => {
    setHasChanges(false);
    unblock();
  }, [unblock]);

  useEffect(() => {
    if (isSubmitting) {
      setHasSubmitted(true);
    }
  }, [isSubmitting, setHasSubmitted]);

  useEffect(() => {
    if (isDirty) {
      setHasChanges(true);
    }
  }, [isDirty, setHasChanges]);

  return useMemo(() => {
    return {
      isOpen: showPrompt,
      onUnblockTransition: handleUnblockTransition,
      setIsOpen: setShowPrompt,
    };
  }, [handleUnblockTransition, setShowPrompt, showPrompt]);
};
