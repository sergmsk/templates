import { useUserProfile } from './useUserProfile';

export const useUserName = (): string => {
  const userProfile = useUserProfile();

  if (!userProfile?.name) {
    return '';
  }

  return userProfile.name
    .trim()
    .split(/\s+/)
    .map((item, idx) => (idx > 0 ? `${item[0].toUpperCase()}.` : item))
    .join(' ');
};
