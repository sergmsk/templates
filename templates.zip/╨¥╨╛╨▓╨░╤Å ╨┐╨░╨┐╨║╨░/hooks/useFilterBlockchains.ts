import { useBlockchainDictionary } from '~/shared/hooks/index';
import type { TBlockchainFeatureMapping } from '~/shared/featureFlag';
import { useCheckFlag } from '~/shared/featureFlag';

type TUseFilterBlockchainsReturn = ReturnType<typeof useBlockchainDictionary>;

export const useFilterBlockchains = (
  featureMapping?: TBlockchainFeatureMapping,
): TUseFilterBlockchainsReturn => {
  const { blockchains, ...rest } = useBlockchainDictionary();
  const checkFlag = useCheckFlag();

  const filteredBlockchains = featureMapping
    ? blockchains.filter(({ id }) => {
        const featureFlag = featureMapping[id];

        if (!featureFlag) {
          return false;
        }

        return checkFlag(featureFlag);
      })
    : blockchains;

  return { blockchains: filteredBlockchains, ...rest };
};
