import { useCallback } from 'react';
import { useCurrencyStore } from './store';

export const useChangeCurrency = () => {
  const [currency, setCurrency] = useCurrencyStore();

  const onChangeCurrency = useCallback(
    async (value) => {
      await setCurrency(value);
    },
    [setCurrency],
  );

  return { currency, onChangeCurrency };
};
