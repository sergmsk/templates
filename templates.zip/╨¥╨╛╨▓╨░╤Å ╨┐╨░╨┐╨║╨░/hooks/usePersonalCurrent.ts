import type { TPersonalCurrent } from '~/shared/api/usermanagement/user';
import { useMainRouteData } from '~/shared/hooks/useMainRouteData';

export const usePersonalCurrent = (): TPersonalCurrent | null => {
  const mainRouteData = useMainRouteData();

  return mainRouteData?.personalCurrent ?? null;
};
