import { useCallback } from 'react';
import { useFormContext, useUpdateControlledField } from 'remix-validated-form';

type TUseResetFormChangesReturn = () => void;

export function useResetFormChanges(formId?: string): TUseResetFormChangesReturn {
  const updateField = useUpdateControlledField(formId);
  const { defaultValues, touchedFields, setFieldTouched } = useFormContext(formId);

  return useCallback(() => {
    const entries = Object.entries(touchedFields);

    entries.forEach(([key, value]) => {
      if (!value) {
        return;
      }

      updateField(key, defaultValues?.[key] ?? '');
      setFieldTouched(key, false);
    });
  }, [defaultValues, touchedFields, setFieldTouched, updateField]);
}
