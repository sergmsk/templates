import { useMemo } from 'react';
import type { TUseFormatNumberModelResponse } from './useFormatNumberModel';
import { useFormatNumberModel } from './useFormatNumberModel';

type TUseFormatPercentResponse = {
  formatPercent: TUseFormatNumberModelResponse;
};

/**
 * Hook returns function for PERCENT with preset options.
 * You can override them, or add other options
 *
 * @param defaultOptions
 */
export const useFormatPercent = (
  defaultOptions?: Intl.NumberFormatOptions,
): TUseFormatPercentResponse => {
  const options = useMemo(
    () => ({
      style: 'percent',
      ...defaultOptions,
    }),
    [defaultOptions],
  );
  const formatPercent = useFormatNumberModel(options);

  return {
    formatPercent,
  };
};
