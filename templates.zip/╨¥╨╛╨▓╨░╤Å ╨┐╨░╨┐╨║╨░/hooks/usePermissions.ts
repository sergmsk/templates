import type { EPermissions } from '~/shared/enums';
import { useUserProfile } from './useUserProfile';

export const usePermissions = (): EPermissions[] | null => {
  const userProfile = useUserProfile();
  if (!userProfile) {
    return null;
  }

  return userProfile.groups as EPermissions[];
};
