import { useLoaderData } from '@remix-run/react';
import { useTranslatedData } from '~/shared/hooks/index';

export const useTranslatedLoaderData = <Data>(): Data | null => {
  const actionData = useLoaderData<string>();
  const translatedData = useTranslatedData<Data>(actionData);

  return translatedData;
};
