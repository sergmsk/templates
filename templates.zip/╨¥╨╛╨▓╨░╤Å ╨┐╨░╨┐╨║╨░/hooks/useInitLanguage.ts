import type { TUseStoreResult } from '@pb/store';
import { useChangeLanguage } from 'remix-i18next';
import type { ELanguages } from '~/shared/enums';
import { useLanguageStore } from './store';

type UseLanguage = () => TUseStoreResult<ELanguages>;

export const useInitLanguage: UseLanguage = () => {
  const [language, setLanguage] = useLanguageStore();
  useChangeLanguage(language);

  return [language, setLanguage];
};
