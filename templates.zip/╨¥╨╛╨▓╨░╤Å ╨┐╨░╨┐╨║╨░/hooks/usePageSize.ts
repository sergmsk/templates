import { useCallback, useState } from 'react';
import { usePageSizeStore } from './store';

type TChangePageSize = (pageSize: number) => Promise<void>;
type TUsePageSizeReturn = [number, TChangePageSize];

export const usePageSize = (
  initialValue?: number | (() => number | undefined),
): TUsePageSizeReturn => {
  const [storePageSize, setStorePageSize] = usePageSizeStore();
  const [pageSize, setPageSize] = useState(() => {
    let value: number | undefined;

    if (typeof initialValue === 'function') {
      value = initialValue();
    } else {
      value = initialValue;
    }

    return value ?? storePageSize;
  });
  const changePageSize: TChangePageSize = useCallback(
    async (value) => {
      await setStorePageSize(value);
      setPageSize(value);
    },
    [setStorePageSize],
  );

  return [pageSize, changePageSize];
};
