import { useCallback } from 'react';

import type { TTokenV1 } from '~/shared/api/contracts-service';
import { TOKEN_UNKNOWN } from '~/shared/chain';
import { useProxyUrl } from '~/shared/hooks/useProxyUrl';

export const useGetTokenUrl = () => {
  const { proxyUrl } = useProxyUrl();

  const getTokenUrl = useCallback(
    (token?: TTokenV1) => {
      if (!token) return TOKEN_UNKNOWN.iconHref;

      return token.iconHref && token.iconHref !== TOKEN_UNKNOWN.iconHref
        ? `${proxyUrl}${token.iconHref}`
        : TOKEN_UNKNOWN.iconHref;
    },
    [proxyUrl],
  );

  return { getTokenUrl };
};
