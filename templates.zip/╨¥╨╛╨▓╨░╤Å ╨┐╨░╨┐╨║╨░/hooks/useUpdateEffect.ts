import { useEffect, useRef } from 'react';

export const useUpdateEffect = function (effectCallback: () => void, deps: Array<any>) {
  const isFirstMount = useRef(false);

  useEffect(() => {
    return () => {
      isFirstMount.current = false;
    };
  }, []);

  useEffect(() => {
    // Do not execute effectCallback for the first time
    if (!isFirstMount.current) {
      isFirstMount.current = true;
    } else {
      return effectCallback();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
};
