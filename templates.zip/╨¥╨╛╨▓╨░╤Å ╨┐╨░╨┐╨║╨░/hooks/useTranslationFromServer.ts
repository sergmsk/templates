import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { getTranslationFromServer } from '~/utils';

export function useTranslationFromServer(data?: null | string | Record<string, string>): string {
  const { i18n } = useTranslation();

  return useMemo(() => {
    return getTranslationFromServer(data, i18n.language);
  }, [data, i18n.language]);
}
