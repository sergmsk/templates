import { useSearchParams } from '@remix-run/react';

export function useInitialQuery(fieldName: string) {
  const [searchParams] = useSearchParams();
  return searchParams.has('query') ? { [fieldName]: searchParams.get('query') } : undefined;
}
