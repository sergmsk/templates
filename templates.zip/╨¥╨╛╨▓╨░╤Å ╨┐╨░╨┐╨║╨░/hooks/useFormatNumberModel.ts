import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { ELocales } from '~/shared/locales';
import { getReplacedAmount } from '~/utils';

export type TUseFormatNumberModelResponse = (
  amount: string | number,
  options?: Intl.NumberFormatOptions,
) => string;

/**
 * !!! NOTE: You mustn't export this function in your code except useNumberFormat, useCurrencyFormat, usePercentFormat !!!
 * Hook returns empty function for different cases.
 *
 * @param defaultOptions
 */

export const useFormatNumberModel = (
  defaultOptions?: Intl.NumberFormatOptions,
): TUseFormatNumberModelResponse => {
  const { i18n } = useTranslation();

  const format = useCallback(
    (amount: string | number, options: any) => {
      let numberForFormatting: number | bigint = 0;

      switch (typeof amount) {
        case 'number':
          numberForFormatting = amount;

          break;

        case 'string':
          try {
            numberForFormatting = BigInt(amount);
          } catch (_) {
            numberForFormatting = parseFloat(amount);
          }
          break;
      }

      return getReplacedAmount(
        new Intl.NumberFormat(ELocales[i18n.language], {
          ...defaultOptions,
          ...options,
        }).format(numberForFormatting),
      );
    },
    [i18n.language, defaultOptions],
  );

  return format;
};
