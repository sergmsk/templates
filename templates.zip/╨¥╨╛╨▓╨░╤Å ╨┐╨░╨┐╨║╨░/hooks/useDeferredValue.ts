import debounce from 'lodash/debounce';
import { useCallback, useEffect, useState } from 'react';

export function useDeferredValue<T>(value: T, setValue: (value: T) => void, timeout = 250) {
  const [instantValue, setInstantValue] = useState(value);

  useEffect(() => {
    setInstantValue(value);
  }, [value]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const deferredSetValue = useCallback(debounce(setValue, timeout), [setValue, timeout]);

  const handleSetInstantValue = useCallback(
    (value: T) => {
      setInstantValue(value);
      deferredSetValue(value);
    },
    [deferredSetValue],
  );

  return [instantValue, handleSetInstantValue] as const;
}
