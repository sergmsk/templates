import * as React from 'react';

import type { TRightSidebarState } from '~/shared/context';
import { RightSidebarCtx } from '~/shared/context';

export function useRightSidebarContext(): TRightSidebarState | null {
  return React.useContext(RightSidebarCtx);
}

export function useRightSidebarState(): TRightSidebarState {
  const rightSidebarRef = React.useRef(null);
  const [isRightSidebarOpen, setRightSidebarOpen] = React.useState(false);

  return React.useMemo(() => {
    return {
      ref: rightSidebarRef,
      isOpen: isRightSidebarOpen,
      close: () => setRightSidebarOpen(false),
      open: () => {
        setRightSidebarOpen(true);
      },
      toggle: () =>
        setRightSidebarOpen((prev) => {
          return !prev;
        }),
    };
  }, [rightSidebarRef, isRightSidebarOpen, setRightSidebarOpen]);
}
