import { useParticipantDictionaries } from '~/shared/hooks/index';
import type { TTagSource } from '~/shared/api/partymanagement';

export const useTagSourceDictionary = (): TTagSource[] | null => {
  const dicts = useParticipantDictionaries();

  return dicts?.tagSources ?? null;
};
