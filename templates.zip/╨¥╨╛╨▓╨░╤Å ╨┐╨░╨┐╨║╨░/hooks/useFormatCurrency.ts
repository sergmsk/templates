import type BigDecimal from 'big.js';
import { useMemo, useCallback } from 'react';
import { getCorrectFormatAmount } from '~/utils';
import { useFormatNumberModel } from './useFormatNumberModel';

export type TFormatCryptoCurrency = (
  amount: string | number | BigDecimal | null,
  cryptoCurrencyCode?: string | null,
  decimals?: number | null,
  options?: Intl.NumberFormatOptions,
) => string;

type TFormatCurrency = (
  amount: string | number,
  currencyCode: string,
  options?: Intl.NumberFormatOptions,
) => string;

type TUseFormatCurrencyResponse = {
  formatCryptoCurrency: TFormatCryptoCurrency;
  formatCurrency: TFormatCurrency;
};

const UNKNOWN_CRYPTO_CURRENCY_RESULT = '-';
const BLANK_CURRENCY = 'CCC';

/**
 * Hook returns function for CURRENCY with preset options.
 * You can override them, or add other options
 *
 * @param defaultOptions
 */
export const useFormatCurrency = (
  defaultOptions?: Intl.NumberFormatOptions,
): TUseFormatCurrencyResponse => {
  const cryptoCurrencyOptions = useMemo(
    () => ({
      style: 'currency',
      currencyDisplay: 'name',
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
      ...defaultOptions,
    }),
    [defaultOptions],
  );
  const formatCryptoCurrencyBase = useFormatNumberModel(cryptoCurrencyOptions);

  const formatCryptoCurrency = useCallback<TFormatCryptoCurrency>(
    (amount, cryptoCurrencyCode, decimals = 0, options) => {
      if (!cryptoCurrencyCode || decimals === undefined || decimals === null || amount === null) {
        return UNKNOWN_CRYPTO_CURRENCY_RESULT;
      }

      const newAmount = getCorrectFormatAmount(amount, decimals);
      const currency = cryptoCurrencyCode.toUpperCase();

      try {
        return formatCryptoCurrencyBase(newAmount, { ...options, currency });
      } catch (error) {
        const blankAmount = formatCryptoCurrencyBase(newAmount, {
          ...options,
          currency: BLANK_CURRENCY,
        });

        return blankAmount.replace(new RegExp(BLANK_CURRENCY, 'i'), currency);
      }
    },
    [formatCryptoCurrencyBase],
  );

  const currencyOptions = useMemo(
    () => ({
      style: 'currency',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
      ...defaultOptions,
    }),
    [defaultOptions],
  );
  const formatCurrencyBase = useFormatNumberModel(currencyOptions);
  const formatCurrency = useCallback<TFormatCurrency>(
    (amount, currencyCode, options) => {
      return formatCurrencyBase(amount, { ...options, currency: currencyCode });
    },
    [formatCurrencyBase],
  );

  return {
    formatCryptoCurrency,
    formatCurrency,
  };
};
