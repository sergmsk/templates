import { useEffect } from 'react';

export const useUnmountEffect = (callback) => {
  useEffect(() => {
    return callback;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
};
