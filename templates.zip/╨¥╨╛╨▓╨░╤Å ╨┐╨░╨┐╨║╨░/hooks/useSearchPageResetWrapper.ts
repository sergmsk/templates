import { useCallback } from 'react';
import { useSearchParams } from '@remix-run/react';
import { EFeatureId, useCheckFlag } from '../featureFlag';

export function useSearchPageResetWrapper(onReset?: () => void) {
  const isSearchEnabled = useCheckFlag()(EFeatureId.AdvancedSearchFeature);
  const [searchParams, setSearchParams] = useSearchParams();

  return useCallback(() => {
    if (isSearchEnabled && searchParams.get('query')) {
      searchParams.delete('query');
      setSearchParams(searchParams);
    }

    onReset?.();
  }, [isSearchEnabled, onReset, searchParams, setSearchParams]);
}
