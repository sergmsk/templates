import { useTranslation } from 'react-i18next';
import { Environment } from '~/environment.server';
import { APP_TITLE } from '~/shared/constants';

type TUseAppTitleResponse = {
  appTitle: string;
};

type TUseAppTitle = () => TUseAppTitleResponse;

export const useAppTitle: TUseAppTitle = () => {
  const { t } = useTranslation();

  return {
    appTitle: t(`app:title.${Environment?.APP_TITLE ?? APP_TITLE}`),
  };
};
