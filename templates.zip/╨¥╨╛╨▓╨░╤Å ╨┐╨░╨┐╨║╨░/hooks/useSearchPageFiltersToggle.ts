import { useEffect } from 'react';
import { EFeatureId, useCheckFlag } from '../featureFlag';
import { useRightSidebarContext } from './useRightSidebar';

export function useSearchPageFiltersToggle(shouldToggle: boolean) {
  const checkFlags = useCheckFlag();
  const isSearchEnabled = checkFlags(EFeatureId.AdvancedSearchFeature);
  const sidebarCtx = useRightSidebarContext();

  useEffect(() => {
    if (!isSearchEnabled) return;

    if (shouldToggle) sidebarCtx?.open();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSearchEnabled, shouldToggle]);
}
