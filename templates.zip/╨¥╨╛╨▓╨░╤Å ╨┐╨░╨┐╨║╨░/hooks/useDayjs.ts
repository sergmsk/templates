import dayjs from 'dayjs';
import { useState, useEffect } from 'react';
import 'dayjs/locale/ru';
import { useTranslation } from 'react-i18next';

export type TDayjs = typeof dayjs;

export function useDayjs(): { dayjs: TDayjs } {
  const { i18n } = useTranslation();
  const [dateState] = useState({ dayjs });

  useEffect(() => {
    dateState.dayjs.locale(i18n.language);
  }, [i18n.language]);

  return dateState;
}
