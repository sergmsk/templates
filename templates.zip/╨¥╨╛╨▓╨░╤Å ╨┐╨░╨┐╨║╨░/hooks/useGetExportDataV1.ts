import { useCallback } from 'react';
import { useDayjs } from './useDayjs';
import { useFormatCurrency } from './useFormatCurrency';

type TUseGetAmountV1 = (
  currency: string,
  shouldShowFiat: boolean,
) => {
  amountCellRangeV1: (amountMin, amountMax, amountMinFiat, amountMaxFiat) => string;
  amountCellV1: (amount, amountFiat) => string;
  amountCryptoCellV1: (amount) => string;
  amountFiatCellV1: (amountFiat) => string;
};

type TUseGetFormatData = () => (value: string) => string;

export const useGetAmountV1: TUseGetAmountV1 = (currency, shouldShowFiat) => {
  const { formatCryptoCurrency, formatCurrency } = useFormatCurrency();

  const amountFiatCellV1 = useCallback(
    (amountFiat) => {
      const fiat = amountFiat[currency] ?? 0;
      return shouldShowFiat ? formatCurrency(fiat, currency) : '-';
    },
    [currency, formatCurrency, shouldShowFiat],
  );

  const amountCryptoCellV1 = useCallback(
    (amount) => {
      if (amount && Array.isArray(amount)) {
        return amount
          .map((item) => {
            return formatCryptoCurrency(item.amount, item?.tokenCode);
          })
          .toString();
      }
      return formatCryptoCurrency(amount.amount, amount.tokenCode);
    },
    [formatCryptoCurrency],
  );

  const amountCellV1 = useCallback(
    (amount, amountFiat) => {
      const fiat = amountFiat[currency] ?? 0;
      function getFormattedAmount() {
        if (amount && Array.isArray(amount)) {
          return amount.map((item) => {
            return formatCryptoCurrency(item.amount, item?.tokenCode);
          });
        } else {
          return formatCryptoCurrency(amount.amount, amount.tokenCode);
        }
      }

      return shouldShowFiat
        ? ` ${formatCurrency(fiat, currency)}
          ${getFormattedAmount()}`
        : `${getFormattedAmount()}`;
    },
    [currency, formatCryptoCurrency, formatCurrency, shouldShowFiat],
  );

  const amountCellRangeV1 = useCallback(
    (amountMin, amountMax, amountMinFiat, amountMaxFiat) => {
      const renderAmountFiatCurrency = (amountFiat: Record<string, number | null | undefined>) => {
        const fiat = amountFiat[currency] ?? 0;
        return formatCurrency(fiat, currency);
      };

      const formattedAmountMin = amountMin
        ? formatCryptoCurrency(amountMin.amount, amountMin?.tokenCode)
        : '';
      const formattedAmountMax = amountMax
        ? formatCryptoCurrency(amountMax.amount, amountMax?.tokenCode)
        : '';

      return shouldShowFiat
        ? `${renderAmountFiatCurrency(amountMinFiat)} - ${renderAmountFiatCurrency(amountMaxFiat)}
            ${formattedAmountMin} - ${formattedAmountMax}`
        : ` ${formattedAmountMin} - ${formattedAmountMax}`;
    },
    [currency, formatCryptoCurrency, formatCurrency, shouldShowFiat],
  );

  return { amountCellRangeV1, amountCellV1, amountFiatCellV1, amountCryptoCellV1 };
};

export const useGetFormatDataV1: TUseGetFormatData = () => {
  const { dayjs } = useDayjs();

  const getFormatData = useCallback((value) => dayjs(value).utc().format('DD MMMM YYYY'), [dayjs]);
  return getFormatData;
};
