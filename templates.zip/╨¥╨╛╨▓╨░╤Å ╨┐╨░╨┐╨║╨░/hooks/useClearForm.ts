import { useCallback, useMemo } from 'react';
import { useFormContext, useUpdateControlledField } from 'remix-validated-form';

type TUseClearFormReturn = {
  clearForm: () => void;
  isDirty: boolean;
  hasTouched: boolean;
};

export const useClearForm = (formId?: string): TUseClearFormReturn => {
  const updateField = useUpdateControlledField(formId);
  const { defaultValues, touchedFields, reset, setFieldTouched } = useFormContext(formId);

  const hasTouched = useMemo(() => {
    return Boolean(Object.values(touchedFields).filter(Boolean).length);
  }, [touchedFields]);

  const isDirty = useMemo(() => {
    const hasDefaults = Boolean(Object.values(defaultValues ?? {}).filter(Boolean).length);

    return hasTouched || hasDefaults;
  }, [hasTouched, defaultValues]);

  const clearForm = useCallback(() => {
    reset();

    if (!defaultValues) {
      return;
    }

    const keys = Object.keys(defaultValues);

    keys.forEach((key) => {
      updateField(key, '');
      setFieldTouched(key, false);
    });
  }, [defaultValues, reset, setFieldTouched, updateField]);

  return {
    isDirty,
    hasTouched,
    clearForm,
  };
};
