import { z } from 'zod';

import { personalCurrentSchema } from '~/shared/api/usermanagement/user';
import { flagMapSchema } from '~/shared/featureFlag/schemas';
import { useRouteData } from '~/shared/hooks/useRouteData';
import { keycloakUserSchema } from '~/process/auth';

const ROUTE_ID = 'routes/__main';

const MainRouteDataSchema = z.object({
  userProfile: keycloakUserSchema,
  featureFlags: flagMapSchema,
  personalCurrent: personalCurrentSchema,
  routerPrefix: z.string().nullish(),
  roles: z.string().array(),
});

export type MainRouteData = z.infer<typeof MainRouteDataSchema>;

export const useMainRouteData = () => useRouteData<MainRouteData>(ROUTE_ID, MainRouteDataSchema);
