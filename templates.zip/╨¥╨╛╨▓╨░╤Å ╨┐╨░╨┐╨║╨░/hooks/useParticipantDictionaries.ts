import { useRouteData } from '~/shared/hooks/useRouteData';
import type {
  TParticipantDictionaries,
  TParticipantDictionariesRouteData,
} from '~/shared/api/partymanagement';
import { participantDictionariesRouteDataSchema } from '~/shared/api/partymanagement';

type TUseParticipantDictionaries = () => TParticipantDictionaries | null;

const ROUTE_ID = 'routes/__main';

export const useParticipantDictionaries: TUseParticipantDictionaries = () => {
  const routeData = useRouteData<TParticipantDictionariesRouteData>(
    ROUTE_ID,
    participantDictionariesRouteDataSchema,
  );

  return routeData?.dicts ?? null;
};
