import { useEffect } from 'react';

export const useMountEffect = (callback) => {
  // eslint-disable-next-line
  useEffect(callback, []);
};
