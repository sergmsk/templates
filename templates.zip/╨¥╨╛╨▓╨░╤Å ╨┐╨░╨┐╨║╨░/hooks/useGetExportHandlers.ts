import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import type { TExportDataCSVHandler, TExportDataXLSXHandler, TRowSelection } from '@pb/uikit';
import type { TAuditEvent } from '@pb/audit-sdk';

import { audit } from '~/utils';

export type TExportConfig = Array<{
  header: { key: string; label: string };
  cell?: ({ row, value }) => string;
}>;

type TUseGetExportHandlersProps = {
  content: Array<Record<string, any>>;
  rowSelection: TRowSelection;
  columns: TExportConfig;
  keyForFilter: string;
  hiddenColumns?: string[];
  columnOrder?: string[];
  auditEvent?: TAuditEvent;
};

type TUseGetExportHandlers = (props: TUseGetExportHandlersProps) => {
  handleSaveCSV: TExportDataCSVHandler;
  handleSaveXLSX: TExportDataXLSXHandler;
};

export const useGetExportHandlers: TUseGetExportHandlers = (props) => {
  const { content, rowSelection, columns, keyForFilter, hiddenColumns, columnOrder, auditEvent } =
    props;

  const { t } = useTranslation();

  const filteredColumnIds = columns.map(({ header }) => header.key);
  const filteredColumns = (
    columnOrder
      ?.filter((columnId) => filteredColumnIds.includes(columnId))
      ?.reduce<TExportConfig>(
        (acc, columnId) => [...acc, ...columns.filter(({ header }) => header.key === columnId)],
        [],
      ) ?? columns
  )?.filter(({ header }) => (hiddenColumns ? !hiddenColumns.includes(header.key) : true));

  const handleSaveCSV: TExportDataCSVHandler = useCallback(() => {
    const exportedData = content
      .filter((item) => rowSelection[item[keyForFilter]])
      .map((item) =>
        (filteredColumns ?? []).reduce(
          (acc, { header, cell }) => ({
            ...acc,
            [header.label]: cell ? cell({ value: item[header.key], row: item }) : item[header.key],
          }),
          {},
        ),
      );

    const filteredHeaders = filteredColumns.map(({ header }) => ({
      ...header,
      key: header.label,
    }));

    return {
      csv: exportedData,
      headers: filteredHeaders,
      key: t('common.actions.downloadCSV'),
      onClick: () => {
        if (auditEvent) {
          audit.sendEvent(auditEvent, { eventDetails: { csvData: exportedData } });
        }
      },
    };
  }, [auditEvent, content, filteredColumns, keyForFilter, rowSelection, t]);

  const handleSaveXLSX: TExportDataXLSXHandler = useCallback(() => {
    const exportedData = content
      .filter((item) => rowSelection[item[keyForFilter]])
      .map((item) =>
        (filteredColumns ?? []).reduce(
          (acc, { header, cell }) => ({
            ...acc,
            [header.label]: cell ? cell({ value: item[header.key], row: item }) : item[header.key],
          }),
          {},
        ),
      );

    return {
      xlsx: exportedData,
      key: t('common.actions.downloadXLSX'),
      filteredColumnIds,
      onClick: () => {
        if (auditEvent) {
          audit.sendEvent(auditEvent, { eventDetails: { xlsxData: exportedData } });
        }
      },
    };
  }, [content, t, filteredColumnIds, rowSelection, keyForFilter, filteredColumns, auditEvent]);

  return { handleSaveXLSX, handleSaveCSV };
};
