import { useStore } from '@pb/store';
import type { ELanguages } from '~/shared/enums';
import { EStoreKeys } from '~/shared/enums';

export const useLanguageStore = () => {
  return useStore<ELanguages>(EStoreKeys.Language);
};
