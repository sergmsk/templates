import type { Dispatch, SetStateAction } from 'react';
import { useStore } from '@pb/store';

import { EStoreKeys } from '~/shared/enums';

const SIDEBAR_IS_COLLAPSED_DEFAULT = false;

export const useRightSidebarIsCollapsedStore = () => {
  return useStore(EStoreKeys.SidebarIsCollapsed, SIDEBAR_IS_COLLAPSED_DEFAULT) as unknown as [
    boolean,
    Dispatch<SetStateAction<boolean>>,
  ];
};
