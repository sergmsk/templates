import { useStore } from '@pb/store';
import { EStoreKeys, ETheme } from '~/shared/enums';

export const useThemeStore = () => {
  return useStore<ETheme>(EStoreKeys.Theme, ETheme.Light);
};
