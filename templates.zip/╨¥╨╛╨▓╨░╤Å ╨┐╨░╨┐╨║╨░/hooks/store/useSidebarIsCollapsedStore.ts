import { useStore } from '@pb/store';
import { EStoreKeys } from '~/shared/enums';

const SIDEBAR_IS_COLLAPSED_DEFAULT = false;

export const useSidebarIsCollapsedStore = (): [boolean, (value: boolean) => Promise<unknown>] => {
  return useStore(EStoreKeys.SidebarIsCollapsed, SIDEBAR_IS_COLLAPSED_DEFAULT);
};
