import * as React from 'react';
import { useTranslation } from 'react-i18next';
import type { ELanguages } from '~/shared/enums';
import { useLanguageStore } from '~/shared/hooks';
import { ChangeLanguageCtx } from '~/shared/context';
import dayjs from 'dayjs';

type UseChangeLanguage = () => {
  language: ELanguages;
  onChangeLanguage: (locale: ELanguages) => void;
  isChangingLanguage: boolean;
};

export const useChangeLanguage: UseChangeLanguage = () => {
  const { i18n } = useTranslation();
  const [isChangingLanguage, setIsChangingLanguage] = React.useContext(ChangeLanguageCtx);
  const [language, setLanguage] = useLanguageStore();

  const onChangeLanguage = React.useCallback(
    async (locale: ELanguages) => {
      setIsChangingLanguage(true);
      dayjs.locale(locale);
      i18n.changeLanguage(locale);
      setLanguage(locale);
    },
    [i18n, setLanguage, setIsChangingLanguage],
  );

  return { language, onChangeLanguage, isChangingLanguage };
};
