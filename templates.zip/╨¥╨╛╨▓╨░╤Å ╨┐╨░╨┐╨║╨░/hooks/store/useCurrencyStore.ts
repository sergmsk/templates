import { useStore } from '@pb/store';
import { DEFAULT_CURRENCY } from '~/shared/constants';
import { EStoreKeys } from '~/shared/enums';

export const useCurrencyStore = () => {
  return useStore(EStoreKeys.Currency, DEFAULT_CURRENCY);
};
