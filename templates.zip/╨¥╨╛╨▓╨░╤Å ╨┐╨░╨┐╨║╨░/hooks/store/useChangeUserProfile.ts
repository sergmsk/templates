import { useCallback } from 'react';
import type { TUserProfile } from '~/entities/users/types';
import { useUserProfileStore } from '~/shared/hooks';

type TUseChangeUserProfileResponse = {
  onChangeUserProfile: (user: TUserProfile) => Promise<void>;
  userProfile: TUserProfile;
};

type TUseChangeUserProfile = () => TUseChangeUserProfileResponse;

export const useChangeUserProfile: TUseChangeUserProfile = () => {
  const [userProfile, setUserProfile] = useUserProfileStore();

  const onChangeUserProfile = useCallback(
    async (user: TUserProfile) => {
      await setUserProfile(user);
    },
    [setUserProfile],
  );

  return { userProfile, onChangeUserProfile };
};
