import { useStore } from '@pb/store';
import { EStoreKeys } from '~/shared/enums';

export const useUserProfileStore = () => {
  return useStore(EStoreKeys.UserProfile);
};
