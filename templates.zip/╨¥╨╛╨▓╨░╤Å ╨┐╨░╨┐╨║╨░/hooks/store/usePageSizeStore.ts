import { useStore } from '@pb/store';
import { DEFAULT_PAGE_SIZE_OPTIONS } from '@pb/uikit';
import { EStoreKeys } from '~/shared/enums';

const DEFAULT_PAGE_SIZE = DEFAULT_PAGE_SIZE_OPTIONS[1];

export const usePageSizeStore = () => {
  return useStore<number>(EStoreKeys.PageSize, DEFAULT_PAGE_SIZE);
};
