import { useCallback } from 'react';
import type { TTokensMap } from '../tokens';
import { useDayjs } from './useDayjs';
import { useFormatCurrency } from './useFormatCurrency';

type TUseGetAmount = (
  currency: string,
  tokensMap: TTokensMap,
  shouldShowFiat: boolean,
) => {
  amountCellRange: (amountMin, amountMax, amountMinFiat, amountMaxFiat) => string;
  amountCell: (amount, amountFiat) => string;
  amountCryptoCell: (amount) => string;
  amountFiatCell: (amountFiat) => string;
};

type TUseGetFormatData = () => (value: string) => string;

export const useGetAmount: TUseGetAmount = (currency, tokensMap, shouldShowFiat) => {
  const { formatCryptoCurrency, formatCurrency } = useFormatCurrency();

  const amountFiatCell = useCallback(
    (amountFiat) => {
      const fiat = amountFiat[currency] ?? 0;
      return shouldShowFiat ? formatCurrency(fiat, currency) : '-';
    },
    [currency, formatCurrency, shouldShowFiat],
  );

  const amountCryptoCell = useCallback(
    (amount) => {
      if (amount && Array.isArray(amount)) {
        return amount
          .map((item) => {
            const token = tokensMap?.get(item.currencyId);
            return formatCryptoCurrency(item.amount, token?.code, token?.decimals);
          })
          .toString();
      }
      return formatCryptoCurrency(amount.amount, amount.currencyCode);
    },
    [formatCryptoCurrency, tokensMap],
  );

  const amountCell = useCallback(
    (amount, amountFiat) => {
      const fiat = amountFiat[currency] ?? 0;
      function getFormattedAmount() {
        if (amount && Array.isArray(amount)) {
          return amount.map((item) => {
            const token = tokensMap?.get(item.currencyId);
            return formatCryptoCurrency(item.amount, token?.code, token?.decimals);
          });
        } else {
          return formatCryptoCurrency(amount.amount, amount.currencyCode);
        }
      }

      return shouldShowFiat
        ? ` ${formatCurrency(fiat, currency)}
          ${getFormattedAmount()}`
        : `${getFormattedAmount()}`;
    },
    [currency, formatCryptoCurrency, formatCurrency, shouldShowFiat, tokensMap],
  );

  const amountCellRange = useCallback(
    (amountMin, amountMax, amountMinFiat, amountMaxFiat) => {
      const amountMinToken = amountMin ? tokensMap.get(amountMin?.currencyId) : null;
      const amountMaxToken = amountMax ? tokensMap.get(amountMax?.currencyId) : null;

      const renderAmountFiatCurrency = (amountFiat: Record<string, number | null | undefined>) => {
        const fiat = amountFiat[currency] ?? 0;
        return formatCurrency(fiat, currency);
      };

      const formattedAmountMin = amountMin
        ? formatCryptoCurrency(amountMin.amount, amountMinToken?.code, amountMinToken?.decimals)
        : '';
      const formattedAmountMax = amountMax
        ? formatCryptoCurrency(amountMax.amount, amountMaxToken?.code, amountMaxToken?.decimals)
        : '';

      return shouldShowFiat
        ? `${renderAmountFiatCurrency(amountMinFiat)} - ${renderAmountFiatCurrency(amountMaxFiat)}
            ${formattedAmountMin} - ${formattedAmountMax}`
        : ` ${formattedAmountMin} - ${formattedAmountMax}`;
    },
    [currency, formatCryptoCurrency, formatCurrency, shouldShowFiat, tokensMap],
  );

  return { amountCellRange, amountCell, amountFiatCell, amountCryptoCell };
};

export const useGetFormatData: TUseGetFormatData = () => {
  const { dayjs } = useDayjs();

  const getFormatData = useCallback((value) => dayjs(value).utc().format('DD MMMM YYYY'), [dayjs]);
  return getFormatData;
};
