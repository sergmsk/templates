import { debounce } from 'lodash';
import { useCallback, useEffect, useState } from 'react';

export function useDebounceValue<T>(value: T, timeout?: number) {
  const [deboucedValue, setDebouncedValue] = useState(value);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const setValue = useCallback(debounce(setDebouncedValue, timeout), [setDebouncedValue, timeout]);

  useEffect(() => {
    setValue(value);
  }, [setValue, value]);

  return deboucedValue;
}
