import { useCallback, useState } from 'react';

import { downloadBlobFile } from '~/utils';
import type { EFileFormat } from '~/shared/enums';
import { ERESTMethods } from '~/shared/enums';
import { MIME_TYPE_BY_FORMAT } from '~/shared/chain';

type TProps = {
  path?: string;
  fileName?: string;
  errorText?: string;
  fileFormat?: `${EFileFormat}`;
};

type TResponse = {
  loadFile: (params?: {
    name?: string;
    format?: string;
    path?: string;
    method?: ERESTMethods;
    body?: Record<string, any>;
  }) => void;
  isFileLoading: boolean;
};

export const useDownloadFile = ({ path, fileName, errorText, fileFormat }: TProps): TResponse => {
  const [isFileLoading, setIsFileLoading] = useState(false);

  const loadFile: TResponse['loadFile'] = useCallback(
    async (params) => {
      const name = params?.name ?? fileName;
      const format = params?.format ?? fileFormat;
      const url = params?.path ?? path;
      const method = params?.method ?? ERESTMethods.GET;

      if (!name || !format || !url) {
        console.error('Missing file name or format when downloading');
        return;
      }

      const mimeType = MIME_TYPE_BY_FORMAT[format];

      try {
        setIsFileLoading(true);
        const response = await fetch(url, {
          method,
          body:
            params?.body &&
            ![ERESTMethods.GET, ERESTMethods.HEAD, ERESTMethods.OPTIONS].includes(method)
              ? JSON.stringify(Object.assign({ format }, params.body))
              : undefined,
        });
        if (!response.ok) {
          throw Error();
        }
        const arrayBuffer = await response.arrayBuffer();
        setIsFileLoading(false);
        downloadBlobFile(arrayBuffer, name, format, mimeType);
      } catch (e) {
        setIsFileLoading(false);
        console.error(errorText ?? `error occurred during ${fileFormat} download process:`, e);
      }
    },
    [fileName, path, errorText, fileFormat],
  );

  return {
    loadFile,
    isFileLoading,
  };
};
