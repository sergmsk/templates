import { useCallback } from 'react';
import type { EPermissions } from '~/shared/enums';
import { checkPermission } from '~/utils';
import { usePermissions } from './usePermissions';

type TUseCheckPermissionReturn = (permissions: EPermissions[]) => boolean;

/**
 * @deprecated
 *
 * Использовать новый функционал useCheckRoles
 */
export const useCheckPermission = (): TUseCheckPermissionReturn => {
  const userPermissions = usePermissions();

  return useCallback(
    (permissions: EPermissions[]) => {
      return checkPermission(userPermissions, permissions);
    },
    [userPermissions],
  );
};
