import type { Reducer } from 'react';
import { useReducer } from 'react';

const reducerFn = (prevState, newState) => ({ ...prevState, ...newState });

export const useSetState = <T>(initialValue: T) =>
  useReducer<Reducer<T, Partial<T>>>(reducerFn, initialValue);
