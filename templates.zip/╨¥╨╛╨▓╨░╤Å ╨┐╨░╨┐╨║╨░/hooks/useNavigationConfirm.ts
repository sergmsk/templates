import { useState, useCallback, useEffect } from 'react';
import type { Location, unstable_BlockerFunction } from '@remix-run/react';
import { unstable_useBlocker as useBlocker, useNavigate } from '@remix-run/react';

export function useNavigationConfirm(shouldBlock = false, blocker?: unstable_BlockerFunction) {
  const navigate = useNavigate();
  const [showPrompt, setShowPrompt] = useState(false);

  const [nextRoute, setNextRoute] = useState<{
    shouldNavigate: boolean;
    location?: Location;
  } | null>(null);

  useBlocker((args) => {
    if (nextRoute?.shouldNavigate) {
      setNextRoute(null);
      return false;
    }

    if (shouldBlock && (blocker?.(args) ?? true)) {
      setShowPrompt(true);
      setNextRoute({ shouldNavigate: false, location: args.nextLocation });
      return true;
    }

    return false;
  });

  const unblock = useCallback(() => {
    setShowPrompt(false);
    if (nextRoute?.location) {
      const { location } = nextRoute;
      setNextRoute({ shouldNavigate: true });
      setTimeout(() => navigate(location));
    }
  }, [navigate, nextRoute]);

  useEffect(() => {
    function handleBeforeUnload(e: Event) {
      if (!nextRoute?.shouldNavigate && shouldBlock) {
        e.returnValue = true;
        e.preventDefault();
      }
    }

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [nextRoute?.shouldNavigate, shouldBlock]);

  return { showPrompt, setShowPrompt, unblock };
}
