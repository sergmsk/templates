export function splitArray<T>(array: T[], by: number) {
  const head = array.slice(0, by);
  const rest = array.slice(by);

  return [head, rest] as const;
}
