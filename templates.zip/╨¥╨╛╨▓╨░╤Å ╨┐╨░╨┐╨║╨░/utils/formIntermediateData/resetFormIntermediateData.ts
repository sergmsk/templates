export function resetFormIntermediateData(key: string) {
  sessionStorage.removeItem(key);
}
