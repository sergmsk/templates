export function getFormIntermediateData<T>(key: string): T | undefined {
  try {
    const values = sessionStorage.getItem(key) ?? JSON.stringify({});

    return JSON.parse(values);
  } catch (e) {
    return undefined;
  }
}
