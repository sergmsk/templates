export function setFormIntermediateData(key: string, data: unknown) {
  sessionStorage.setItem(key, JSON.stringify(data));
}
