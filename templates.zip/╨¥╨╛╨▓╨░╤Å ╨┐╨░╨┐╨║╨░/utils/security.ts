import type { Session } from '@remix-run/node';
import type { ParsedQs } from 'qs';
import { getCsrfSession } from '~/process/auth';
import { Environment } from '~/environment.server';
import { parseResponseError } from './responses';
import { getStoreFixedT } from './store';

export const getContentSecurityPolicy = (nonce?: string): string => {
  let script_src: string;
  if (typeof nonce === 'string' && nonce.length > 40) {
    script_src = `'self' 'nonce-${nonce}'`;
  } else if (!Environment.IS_PRODUCTION) {
    // Allow the <LiveReload /> component to load without a nonce in the error pages
    script_src = "'self' 'unsafe-inline'";
  } else {
    script_src = "'self'";
  }

  script_src += ` ${Environment.HOST_URL}/vendor/layout.min.js`;

  const connect_src = Environment.IS_PRODUCTION ? "'self' ws:" : "'self' ws://localhost:*";
  const frame_src = `frame-src ${Environment.SUPERSET_URL} data:; `;
  const frame_ancestors = `frame-ancestors 'self' ${Environment.SUPERSET_URL}; `;

  return (
    "default-src 'self'; " +
    `script-src ${script_src}; ` +
    `style-src 'self' https: 'unsafe-inline'; ` +
    "base-uri 'self'; " +
    'block-all-mixed-content; ' +
    "child-src 'self'; " +
    `connect-src ${connect_src}; ` +
    "img-src 'self' data:; " +
    "font-src 'self' https: data:; " +
    "form-action 'self'; " +
    frame_ancestors +
    frame_src +
    "manifest-src 'self'; " +
    "media-src 'self'; " +
    "object-src 'none'; " +
    "prefetch-src 'self'; " +
    "script-src-attr 'none';" +
    "worker-src 'self' blob:; " +
    'upgrade-insecure-requests'
  );
};

export const validateCSRFToken = async (csrf: string, session: Session, errorMessage: string) => {
  if (!session.has('csrf')) throw new Error(errorMessage);
  if (!csrf) throw new Error(errorMessage);
  if (csrf !== session.get('csrf')) throw new Error(errorMessage);
};

export const checkCSRFToken = async (
  context: any,
  request: Request,
  csrfToken?: string | ParsedQs | string[] | ParsedQs[], // inputFromForm(request) возвращает такие типы
) => {
  const session = await getCsrfSession(request);
  const t = await getStoreFixedT(request);
  const errorMessage = t('errorBoundary:common.unexpectedError');

  // csrf должен быть только string
  if (typeof csrfToken !== 'string') throw new Error(errorMessage);

  try {
    if (!csrfToken) throw new Error(errorMessage);

    await validateCSRFToken(csrfToken, session, errorMessage);

    return { success: true };
  } catch (error) {
    if (error instanceof Error) session.flash('error', error.message);

    return { success: false, error: parseResponseError(error) };
  }
};
