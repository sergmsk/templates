import { expect, it, describe } from 'vitest';
import { getReplacedAmount } from '../getReplacedAmount';

describe.concurrent('Domain | hooks | replace', () => {
  it('should return 100 BTC', () => {
    const amount = '100 BTC';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -100 BTC', () => {
    const amount = '-100 BTC';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return 100.99 BTC', () => {
    const amount = '100.99 BTC';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -100.99 BTC', () => {
    const amount = '-100.99 BTC';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return 100 $', () => {
    const amount = '100 $';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -100 $', () => {
    const amount = '-100 $';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return 100.99 $', () => {
    const amount = '100.99 $';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -100.99 $', () => {
    const amount = '-100.99 $';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -$100', () => {
    const amount = '-$100';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -$100.99', () => {
    const amount = '-$100.99';
    const replacedAmount = '-$100.99';
    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return -$0.99', () => {
    const amount = '-$0.99';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return $0', () => {
    const amount = '-$0';
    const replacedAmount = '$0';

    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return $ 0', () => {
    const amount = '-$ 0';
    const replacedAmount = '$ 0';

    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return BTC 0', () => {
    let amount = '-BTC 0';
    const replacedAmount = 'BTC 0';

    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return BTC 0', () => {
    const amount = 'BTC 0';
    const replacedAmount = 'BTC 0';

    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return 0 BTC', () => {
    const amount = '0 BTC';
    const replacedAmount = '0 BTC';

    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return 0', () => {
    const amount = '0';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return 0', () => {
    const amount = '-0';
    const replacedAmount = '0';
    expect(getReplacedAmount(amount)).toEqual(replacedAmount);
  });

  it('should return 0.12', () => {
    const amount = '0.12';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -0.12', () => {
    const amount = '-0.12';
    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return 0.12', () => {
    const amount = '0.12';

    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return 012', () => {
    const amount = '012';
    expect(getReplacedAmount(amount)).toEqual(amount);
  });

  it('should return -012', () => {
    const amount = '-012';
    expect(getReplacedAmount(amount)).toEqual(amount);
  });
});
