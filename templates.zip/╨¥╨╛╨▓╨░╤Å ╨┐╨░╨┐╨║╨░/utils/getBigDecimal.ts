import Big from 'big.js';
import isNil from 'lodash/isNil';
import { ETH_DECIMAL_COUNT } from '~/shared/chain';

export const getBigDecimal = (num: number | string | Big | null, decimals = ETH_DECIMAL_COUNT) => {
  if (isNil(num)) {
    return new Big(0);
  }
  return new Big(num).div(new Big(`1e${decimals}`));
};
