export function parseTxTypeName(value?: string | null): Record<'ru' | 'eng', string> {
  let result;

  try {
    if (value == null) throw Error();
    result = JSON.parse(value);
  } catch (e) {
    result = { ru: '-', eng: '-' };
  }

  return result;
}
