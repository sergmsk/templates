export function pick<T extends object, K extends keyof T>(source: T, keys: Array<K>): Pick<T, K> {
  const result: any = {};

  for (const key of keys) {
    result[key] = source[key];
  }

  return result;
}
