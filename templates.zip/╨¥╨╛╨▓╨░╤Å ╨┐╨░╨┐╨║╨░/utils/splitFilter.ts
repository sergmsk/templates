export function splitFilter<T>(array: Iterable<T>, predicate: (val: T) => boolean) {
  const filtered: Array<T> = [];
  const rest: Array<T> = [];

  for (const el of array) {
    if (predicate(el)) filtered.push(el);
    else rest.push(el);
  }

  return [filtered, rest] as const;
}
