import dayjs from 'dayjs';
import type {
  TAddressBalanceDynamics,
  TAddressBalanceDynamicsV2,
  TAddressBalanceDynamicsV3,
  TAddressTransactionDynamics,
  TAddressTransactionsDynamicsV2,
  TAddressTransactionsDynamicsV3,
} from '~/shared/api/aggregation';
import type {
  TPrepareBalanceDynamics,
  TPrepareTransactionDynamics,
  TTransactionDynamicsData,
} from '~/types';
import { getCorrectFormatAmount } from './getCorrectFormatAmount';

const DATE_CHART_FORMAT = 'MMM YYYY';

export const prepareTransactionDynamics = (
  dynamics: TAddressTransactionDynamics,
  decimals: number = 0,
): TPrepareTransactionDynamics => {
  let max = 0;
  let min = 0;
  const result = new Map();

  dynamics.inputs.forEach(({ dateEvent, amount }) => {
    const amountNumber = Number(getCorrectFormatAmount(amount, decimals));
    const month = dayjs(dateEvent).format(DATE_CHART_FORMAT);
    const negative = -amountNumber;

    min = Math.min(min, negative);

    result.set(month, {
      month,
      positive: 0,
      negative,
      part: 1,
    });
  });

  dynamics.outputs.forEach(({ dateEvent, amount }) => {
    const amountNumber = Number(getCorrectFormatAmount(amount, decimals));
    const month = dayjs(dateEvent).format(DATE_CHART_FORMAT);

    max = Math.max(max, amountNumber);

    if (result.has(month)) {
      const data = result.get(month);

      data.positive = amountNumber;

      result.set(month, data);
    } else {
      result.set(month, {
        month,
        positive: amountNumber,
        negative: 0,
        part: 1,
      });
    }
  });

  const data = Array.from(result.values()).sort(
    (a: TTransactionDynamicsData, b: TTransactionDynamicsData) =>
      dayjs(a.month, DATE_CHART_FORMAT).diff(dayjs(b.month, DATE_CHART_FORMAT)),
  );

  return {
    min: -Math.max(Math.abs(min), max),
    max: Math.max(Math.abs(min), max),
    data,
  };
};

export const prepareBalanceDynamics = (
  balance: TAddressBalanceDynamics,
  decimals: number = 0,
): TPrepareBalanceDynamics => {
  let max = Number(getCorrectFormatAmount(balance[0].amount, decimals));
  let min = Number(getCorrectFormatAmount(balance[0].amount, decimals));
  const partMap = new Map();

  const data = balance.map((item) => {
    const amount = Number(getCorrectFormatAmount(item.amount, decimals));
    const amountFiat = Number(getCorrectFormatAmount(item.amountFiat ?? 0, decimals));
    const month = dayjs(item.dateEvent).format(DATE_CHART_FORMAT);
    let part = 1;
    if (amount < min) min = amount;
    if (amount > max) max = amount;
    if (partMap.has(month)) {
      part = partMap.get(month) + 1;
      partMap.set(month, part);
    } else {
      partMap.set(month, 1);
    }
    return {
      month,
      value: { crypto: amount, fiat: amountFiat },
      part,
    };
  });

  return {
    data,
    min,
    max,
  };
};

export const prepareTransactionDynamicsV2 = (
  dynamics: TAddressTransactionsDynamicsV2,
  currency: string,
  decimals?: number,
): TPrepareTransactionDynamics => {
  let max = 0;
  let min = 0;
  let maxFiat = 0;
  let minFiat = 0;

  const positiveMap = (dynamics?.received ?? []).reduce((map, { dateFrom, amount, amountFiat }) => {
    const amountNumber = Number(getCorrectFormatAmount(amount, decimals));
    const amountFiatNumber = amountFiat[currency];
    const positiveCrypto = amountNumber;
    const positiveFiat = amountFiatNumber;

    max = Math.max(max, positiveCrypto);
    maxFiat = Math.max(maxFiat, positiveFiat);

    map.set(dateFrom, { crypto: positiveCrypto, fiat: positiveFiat });

    return map;
  }, new Map<string, TTransactionDynamicsData['positive']>());

  const negativeMap = (dynamics?.sent ?? []).reduce((map, { dateFrom, amount, amountFiat }) => {
    const amountNumber = Number(getCorrectFormatAmount(amount, decimals));
    const amountFiatNumber = amountFiat[currency];
    const negativeCrypto = -amountNumber;
    const negativeFiat = amountFiatNumber;

    min = Math.min(min, negativeCrypto);
    minFiat = Math.min(minFiat, negativeFiat);

    map.set(dateFrom, { crypto: negativeCrypto, fiat: negativeFiat });

    return map;
  }, new Map<string, TTransactionDynamicsData['negative']>());

  const dates = Array.from(new Set([...positiveMap.keys(), ...negativeMap.keys()])).sort(
    (a: string, b: string) => dayjs(a).diff(dayjs(b)),
  );
  const resultMap = (dates ?? []).reduce((map, date) => {
    const INITIAL_AMOUNT = { crypto: 0, fiat: 0 };
    const month = dayjs(date).format(DATE_CHART_FORMAT);
    const positive = positiveMap.get(date) ?? INITIAL_AMOUNT;
    const negative = negativeMap.get(date) ?? INITIAL_AMOUNT;
    const item = map.get(month) ?? {
      month,
      positive: INITIAL_AMOUNT,
      negative: INITIAL_AMOUNT,
    };

    map.set(month, {
      ...item,
      positive: {
        crypto: item.positive.crypto + positive.crypto,
        fiat: item.positive.fiat + positive.fiat,
      },
      negative: {
        crypto: item.negative.crypto + negative.crypto,
        fiat: item.negative.fiat + negative.fiat,
      },
    });

    return map;
  }, new Map<string, Omit<TTransactionDynamicsData, 'part'>>());

  const data: TTransactionDynamicsData[] = Array.from(resultMap.values()).map((item, index) => ({
    ...item,
    part: index + 1,
  }));

  return {
    min: -Math.max(Math.abs(min), max),
    max: Math.max(Math.abs(min), max),
    data,
  };
};

export const prepareTransactionDynamicsV3 = (
  dynamics: TAddressTransactionsDynamicsV3,
  currency: string,
): TPrepareTransactionDynamics => {
  let max = 0;
  let min = 0;
  let maxFiat = 0;
  let minFiat = 0;

  const positiveMap = (dynamics?.received ?? []).reduce((map, { dateFrom, amount }) => {
    const amountNumber = Number(getCorrectFormatAmount(amount?.amount ?? 0));
    const amountFiatNumber = amount.fiat?.[currency];
    const positiveCrypto = amountNumber;
    const positiveFiat = amountFiatNumber;

    max = Math.max(max, positiveCrypto);
    maxFiat = Math.max(maxFiat, positiveFiat);

    map.set(dateFrom, { crypto: positiveCrypto, fiat: positiveFiat });

    return map;
  }, new Map<string, TTransactionDynamicsData['positive']>());

  const negativeMap = (dynamics?.sent ?? []).reduce((map, { dateFrom, amount }) => {
    const amountNumber = Number(getCorrectFormatAmount(amount?.amount ?? 0));
    const amountFiatNumber = amount.fiat?.[currency];
    const negativeCrypto = -amountNumber;
    const negativeFiat = amountFiatNumber;

    min = Math.min(min, negativeCrypto);
    minFiat = Math.min(minFiat, negativeFiat);

    map.set(dateFrom, { crypto: negativeCrypto, fiat: negativeFiat });

    return map;
  }, new Map<string, TTransactionDynamicsData['negative']>());

  const dates = Array.from(new Set([...positiveMap.keys(), ...negativeMap.keys()])).sort(
    (a: string, b: string) => dayjs(a).diff(dayjs(b)),
  );
  const resultMap = (dates ?? []).reduce((map, date) => {
    const INITIAL_AMOUNT = { crypto: 0, fiat: 0 };
    const month = dayjs(date).format(DATE_CHART_FORMAT);
    const positive = positiveMap.get(date) ?? INITIAL_AMOUNT;
    const negative = negativeMap.get(date) ?? INITIAL_AMOUNT;
    const item = map.get(month) ?? {
      month,
      positive: INITIAL_AMOUNT,
      negative: INITIAL_AMOUNT,
    };

    map.set(month, {
      ...item,
      positive: {
        crypto: item.positive.crypto + positive.crypto,
        fiat: item.positive.fiat + positive.fiat,
      },
      negative: {
        crypto: item.negative.crypto + negative.crypto,
        fiat: item.negative.fiat + negative.fiat,
      },
    });

    return map;
  }, new Map<string, Omit<TTransactionDynamicsData, 'part'>>());

  const data: TTransactionDynamicsData[] = Array.from(resultMap.values()).map((item, index) => ({
    ...item,
    part: index + 1,
  }));

  return {
    min: -Math.max(Math.abs(min), max),
    max: Math.max(Math.abs(min), max),
    data,
  };
};

export const prepareBalanceDynamicsV2 = (
  balance: TAddressBalanceDynamicsV2,
  currency: string,
  decimals?: number,
): TPrepareBalanceDynamics => {
  let max = Number(getCorrectFormatAmount(balance.balances[0].amount, decimals));
  let min = Number(getCorrectFormatAmount(balance.balances[0].amount, decimals));
  const partMap = new Map();

  const data = balance.balances.map((item) => {
    const amount = Number(getCorrectFormatAmount(item.amount, decimals));
    const amountFiat = item.amountFiat[currency];
    const month = dayjs(item.dateFrom).format(DATE_CHART_FORMAT);
    let part = 1;
    if (amount < min) min = amount;
    if (amount > max) max = amount;
    if (partMap.has(month)) {
      part = partMap.get(month) + 1;
      partMap.set(month, part);
    } else {
      partMap.set(month, 1);
    }
    return {
      month,
      value: { crypto: amount, fiat: amountFiat },
      part,
    };
  });

  return {
    data,
    min,
    max,
  };
};

export const prepareBalanceDynamicsV3 = (
  balance: TAddressBalanceDynamicsV3,
  currency: string,
): TPrepareBalanceDynamics => {
  let max = Number(getCorrectFormatAmount(balance.balances[0]?.amount?.amount ?? 0));
  let min = Number(getCorrectFormatAmount(balance.balances[0]?.amount?.amount ?? 0));
  const partMap = new Map();

  const data = balance.balances.map((item) => {
    const amount = Number(getCorrectFormatAmount(item?.amount?.amount ?? 0));
    const amountFiat = item.amount?.fiat?.[currency] ?? 0;
    const month = dayjs(item.dateFrom).format(DATE_CHART_FORMAT);
    let part = 1;
    if (amount < min) min = amount;
    if (amount > max) max = amount;
    if (partMap.has(month)) {
      part = partMap.get(month) + 1;
      partMap.set(month, part);
    } else {
      partMap.set(month, 1);
    }
    return {
      month,
      value: { crypto: amount, fiat: amountFiat },
      part,
    };
  });

  return {
    data,
    min,
    max,
  };
};
