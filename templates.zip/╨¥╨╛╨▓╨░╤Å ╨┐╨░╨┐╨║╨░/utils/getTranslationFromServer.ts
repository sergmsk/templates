import { ELanguages } from '~/shared/enums';

export function getTranslationFromServer(
  data?: null | string | Record<string, string>,
  locale?: string,
): string {
  if (data == null) return '';
  if (typeof data === 'object') return data[locale ?? ELanguages.Ru];

  try {
    return JSON.parse(data)?.[locale ?? ELanguages.Ru];
  } catch (e) {
    return data;
  }
}
