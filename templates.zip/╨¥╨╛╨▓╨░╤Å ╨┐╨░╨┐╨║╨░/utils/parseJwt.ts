import jwtDecode from 'jwt-decode';

export const parseJwt = (token) => {
  try {
    return jwtDecode<Record<string, any>>(token);
  } catch (error) {
    console.error(error);
    return null;
  }
};
