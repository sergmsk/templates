type TRedirectToLink = (link: string) => void;

export const redirectToLink: TRedirectToLink = (link) => {
  const a = document.createElement('a');

  a.href = link;
  a.click();
  a.remove();
};
