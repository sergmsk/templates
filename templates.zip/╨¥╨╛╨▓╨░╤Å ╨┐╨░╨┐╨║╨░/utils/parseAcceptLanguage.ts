import acceptLanguage from 'accept-language-parser';
import { ELanguages } from '~/shared/enums';

export function parseAcceptLanguage(request: Request): string {
  const acceptLanguages = acceptLanguage.parse(request.headers.get('Accept-Language') as string);

  if (acceptLanguages?.length < 1) return ELanguages.Ru;

  return acceptLanguages[0].code === ELanguages.Ru ? ELanguages.Ru : ELanguages.En;
}
