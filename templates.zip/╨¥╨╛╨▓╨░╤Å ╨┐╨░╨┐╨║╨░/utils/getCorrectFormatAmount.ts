import type Big from 'big.js';

export function getCorrectFormatAmount(
  amount: string | number | Big,
  decimals?: number,
): number | string {
  if (typeof amount !== 'string') {
    return decimals ? Number(amount) / Math.pow(10, decimals) : Number(amount);
  }

  if (!decimals) {
    return amount;
  }

  if (decimals > amount.length) {
    return '0.' + amount.padStart(decimals, '0');
  }

  return amount.slice(0, -decimals) + '.' + amount.slice(-decimals);
}
