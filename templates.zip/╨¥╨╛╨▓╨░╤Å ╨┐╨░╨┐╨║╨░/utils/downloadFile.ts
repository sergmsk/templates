import { BOM_MARKER } from '~/shared/constants';
import { EFileFormat } from '~/shared/enums';

export function downloadBlobFile(
  data: string | ArrayBuffer,
  name: string,
  format: string,
  type?: string,
): void {
  if (format === EFileFormat.Csv && typeof data === 'string') data = BOM_MARKER + data;

  const blob = new Blob([data], {
    type,
  });
  const objectUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = objectUrl;
  a.download = `${name}.${format}`;
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(objectUrl);
  }, 1000);
  a.remove();
}

export function downloadFile(url: string, name: string, format: string): void {
  const a = document.createElement('a');
  a.href = url;
  a.download = `${name}.${format}`;
  a.click();
  a.remove();
}
