import { json } from 'remix';
import type { TypedResponse } from '@remix-run/server-runtime';
import type { ErrorResult, FormDefaults, ValidationErrorResponseData } from 'remix-validated-form';
import { setFormDefaults } from 'remix-validated-form';

type TFormValidationErrorResponseData<TData extends object> = ValidationErrorResponseData &
  FormDefaults &
  TData;

export function formValidationError<TData extends object>(
  formId: string,
  result: ErrorResult,
  data: TData,
): TypedResponse<TFormValidationErrorResponseData<TData>> {
  const defaults = setFormDefaults(formId, result.submittedData);

  const responseData: TFormValidationErrorResponseData<TData> = {
    ...result.error,
    repopulateFields: result.submittedData,
    ...defaults,
    ...data,
  };

  return json(responseData, { status: 422 });
}
