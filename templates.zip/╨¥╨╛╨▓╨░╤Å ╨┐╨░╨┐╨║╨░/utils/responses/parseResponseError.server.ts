import { serverError } from 'remix-utils';
import { json } from '@remix-run/node';
import isFunction from 'lodash/isFunction';

import { getResponseError } from '~/shared/domain';
import type { TFormErrors } from '~/shared/domain';
import type { TActionResponseFailure } from '~/types';

type TNormalize = (errors: TFormErrors) => unknown;
type TParseResponseError = (error: unknown, normalize?: TNormalize) => Promise<Response>;

export const parseResponseError: TParseResponseError = async (error, normalize) => {
  if (!(error instanceof Response)) {
    return serverError<TActionResponseFailure>({
      success: false,
      formError: (error as Error).message,
    });
  }

  const responseError = await getResponseError(error);

  if (!responseError) {
    return serverError<TActionResponseFailure>({ success: false });
  }

  const errors = {
    fieldErrors: responseError.fieldErrors,
    formError: responseError.message,
  };
  const resultErrors = isFunction(normalize) ? normalize(errors) : errors;

  const data: TActionResponseFailure = Object.assign(
    { success: false },
    resultErrors,
  ) as TActionResponseFailure;

  return json(data, { status: error.status });
};
