import { Fragment } from 'react';
import { ErrorBoundary as DefaultErrorBoundary } from '~/components';

export const createErrorBoundary = ({
  Layout = Fragment,
  ErrorBoundary = DefaultErrorBoundary,
}) => {
  const ErrorBoundaryWrapper = ({ error }: { error: Error }) => (
    <Layout>
      <ErrorBoundary error={error} />
    </Layout>
  );

  return ErrorBoundaryWrapper;
};
