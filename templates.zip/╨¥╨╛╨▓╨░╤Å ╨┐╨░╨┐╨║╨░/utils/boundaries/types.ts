import type { ComponentType } from 'react';
import type { ErrorBoundaryComponent } from 'remix';
import type { TFunction } from 'i18next';

export type TErrorBoundaries = {
  ErrorBoundary: ErrorBoundaryComponent;
  CatchBoundary: ComponentType;
};

export type TCatchBoundaryMessageFunction = (t: TFunction) => string;

export type TCatchBoundaryMessage = string | TCatchBoundaryMessageFunction;

export type TCatchBoundaryStatusMap = Map<number, TCatchBoundaryMessage>;
