export const replaceAmountRegExp = /^-([^.\d]*)0$|-0([^.\d]*$)/;

export function getReplacedAmount(amount: string): string {
  return amount.replace(replaceAmountRegExp, '$10$2').replace(/\u00A0/g, ' ');
}
