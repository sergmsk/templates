export const removeFromArray = <T = unknown>(index: number, array: T[]) => [
  ...array.slice(0, index),
  ...array.slice(index + 1),
];
