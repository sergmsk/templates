import type { DataFunctionArgs } from '@remix-run/server-runtime';
import { redirect } from 'remix';
import type { ActionFunction, LoaderFunction } from '@remix-run/node';
import { ERoutes } from '~/shared/enums';
import { createPath } from '~/utils';
import type { ERoles } from '~/shared/checkRoles';
import { checkRoles } from '~/shared/checkRoles';

type TWrapDataFunctionConfig = {
  role: ERoles;
  redirectUrl?: string;
};

export const wrapDataFunction = <TDataFunction extends ActionFunction | LoaderFunction>(
  { role, redirectUrl = createPath({ route: ERoutes.Root }) }: TWrapDataFunctionConfig,
  dataFunction: TDataFunction,
): TDataFunction =>
  (async (args: DataFunctionArgs) => {
    const hasPermission = await checkRoles(args.request, role);
    if (!hasPermission) {
      return redirect(redirectUrl);
    }

    return dataFunction(args);
  }) as TDataFunction;
