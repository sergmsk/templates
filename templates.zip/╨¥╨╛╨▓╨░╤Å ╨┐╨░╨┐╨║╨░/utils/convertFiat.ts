import type { TCurrency } from '~/shared/api/aggregation';
import { getBigDecimal } from './getBigDecimal';

export const convertFiat = (fiats: TCurrency, decimals: number): TCurrency =>
  Object.entries(fiats).reduce((fiats, [currency, amount]) => {
    fiats[currency] = getBigDecimal(amount, decimals).toNumber();
    return fiats;
  }, {});
