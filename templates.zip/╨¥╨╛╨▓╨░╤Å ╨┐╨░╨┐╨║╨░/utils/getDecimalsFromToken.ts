import type { TTokensV1 } from '~/shared/api/contracts-service';
import { TOKENS_BY_ID } from '~/shared/chain/tokenTypes';

export function getDecimalsFromToken(code: string, tokenList?: TTokensV1): number {
  const getToken = () => {
    if (tokenList) {
      return tokenList.find((item) => item.code === code);
    } else {
      return Object.values(TOKENS_BY_ID).find((item) => {
        return item.code === code;
      });
    }
  };

  const token = getToken();

  if (token && token.decimals) {
    return token.decimals;
  }
  return 0;
}
