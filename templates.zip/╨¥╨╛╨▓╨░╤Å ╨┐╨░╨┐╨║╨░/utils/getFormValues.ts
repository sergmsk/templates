import { inputFromFormData, inputFromSearch } from 'remix-domains';
import { coerceValue } from 'remix-forms/lib/coercions';
import type { AnyZodObject } from 'zod';
import type z from 'zod';

async function getFormValues<Schema extends AnyZodObject>(
  request: Request,
  schema: Schema,
): Promise<Partial<Record<keyof z.infer<Schema>, any>>> {
  let formData: Record<string, any>;
  if (request.method === 'GET') {
    formData = inputFromSearch(new URL(request.url).searchParams);
  } else {
    formData = inputFromFormData(await request.formData());
  }

  let values: Partial<Record<keyof Schema, any>> = {};

  for (const key in schema.shape) {
    const value =
      formData[key] === 'true' ? true : formData[key] === 'false' ? false : formData[key];
    const shape = schema.shape[key];
    values[key as keyof z.infer<Schema>] = coerceValue(value, shape);
  }

  return values;
}

export { getFormValues };
