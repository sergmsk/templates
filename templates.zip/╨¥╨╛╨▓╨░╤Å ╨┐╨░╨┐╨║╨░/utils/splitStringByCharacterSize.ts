/**
 * Разделяет строку на части путём количества символов
 * @example
 * // вернёт ['ab', 'cd', 'e']
 * splitStringByCharactersSize('abcde', 2)
 * @example
 * // вернёт ['abc', 'def']
 * splitStringByCharactersSize('abcdef', 3)
 * @param {string} text - Строка которую нужно разделить
 * @param {number} size - Количество символов по которому нужно разделять
 * @returns {Array.<String>>} Возвращает массив частей разделённых по количеству символов.
 */
export function splitStringByCharactersSize(text: string, size: number): string[] {
  if (text.length <= size) return [text];

  const chunkCount = Math.ceil(text.length / size);
  const result: string[] = [];

  for (let i = 0; i < chunkCount; i++) {
    result.push(text.slice(i * size, i === chunkCount - 1 ? undefined : (i + 1) * size));
  }

  return result;
}
