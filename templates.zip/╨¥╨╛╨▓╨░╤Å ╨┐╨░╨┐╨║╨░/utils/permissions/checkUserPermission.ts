import type { EPermissions } from '~/shared/enums';
import type { TKeycloakUser } from '~/types';
import { checkPermission } from './checkPermission';

/**
 * @deprecated
 *
 * Использовать новый функционал useCheckRoles
 */
export function checkUserPermission(
  user: TKeycloakUser | null,
  permissions: EPermissions[],
): boolean {
  return checkPermission((user?.groups ?? null) as EPermissions[] | null, permissions);
}
