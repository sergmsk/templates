import type { EPermissions } from '~/shared/enums';
import { userProfileStorage } from '~/process/auth';
import { checkUserPermission } from './checkUserPermission';
import type { TKeycloakUser } from '~/types';

/**
 * @deprecated
 *
 * Использовать новый функционал checkRoles
 */
export async function checkRequestPermission(
  request: Request,
  permissions: EPermissions[],
): Promise<boolean> {
  const session = await userProfileStorage.getSession(request.headers.get('Cookie'));
  return checkUserPermission(session.data as TKeycloakUser, permissions);
}
