import isNil from 'lodash/isNil';
import pickBy from 'lodash/pickBy';
import type { TFunction } from 'i18next';
import type { TParams } from '~/types';
import { translateRawData } from '~/utils';

export function getFieldErrors(
  formState: TParams,
  t?: TFunction,
): Record<string, string | any | undefined> {
  const errorKeys = Object.keys(formState?.errors ?? {});
  return (errorKeys ?? []).reduce((acc, errorKey) => {
    if (Array.isArray(formState?.errors?.[errorKey])) {
      const arrFieldsErrors = formState?.errors?.[errorKey][0];
      acc[errorKey] = {};
      for (let key in arrFieldsErrors) {
        const message = arrFieldsErrors[key]?.message;
        acc[errorKey][key] = t ? translateRawData(t, message) : message;
      }
    } else {
      const message = formState?.errors?.[errorKey]?.message;
      if (!message) {
        acc[errorKey] = {};
        for (let key in formState?.errors?.[errorKey]) {
          const message = formState?.errors?.[errorKey][key]?.message;
          acc[errorKey][key] = t ? translateRawData(t, message) : message;
        }
      } else {
        acc[errorKey] = t ? translateRawData(t, message) : message;
      }
    }
    return acc;
  }, {});
}

export function omitEmptyFields<T extends TParams>(fields: T): TParams {
  return pickBy<T>(fields, (field: any) => {
    if (isNil(field) || ((typeof field === 'string' || Array.isArray(field)) && !field.length)) {
      return false;
    }

    return true;
  });
}

export function createFormData(values: TParams): FormData {
  const formData = new FormData();

  Object.entries(values).forEach(([key, value]) => {
    formData.append(key, value);
  });

  return formData;
}
