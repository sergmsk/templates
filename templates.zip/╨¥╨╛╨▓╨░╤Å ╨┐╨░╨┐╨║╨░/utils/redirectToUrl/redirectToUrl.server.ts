import type { TypedResponse } from '@remix-run/node';
import { redirect } from '@remix-run/node';

import { REDIRECT_TO } from './constants';

export function redirectToUrl(request: Request, url: string): TypedResponse {
  const requestUrl = new URL(request.url);
  const redirectTo = encodeURI(requestUrl.searchParams.get(REDIRECT_TO) ?? '');

  return redirect(redirectTo || url);
}
