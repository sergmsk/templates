import type { TTableSortingParams } from '@pb/uikit';

export const mapTableSortingToDto = (params?: TTableSortingParams) => {
  // multi sorting
  if (Array.isArray(params)) {
    return {
      sortOrders: params?.map((item) => ({
        field: item.sortProperty,
        sortDirection: item.sortDirection,
      })),
    };
  }

  // single sorting
  return {
    sortProperty: params?.sortProperty,
    sortDirection: params?.sortDirection,
  };
};
