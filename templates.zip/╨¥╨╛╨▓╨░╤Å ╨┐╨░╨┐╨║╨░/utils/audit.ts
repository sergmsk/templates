import type { EBackendEventType, EClientEventType, EKeycloakEventAction } from '@pb/audit-sdk';
import { ERoutes } from '~/shared/enums';
import { createPath } from './createPath';

const sendEvent = async (
  event: EBackendEventType | EClientEventType | EKeycloakEventAction,
  params?: {
    objectId?: string;
    objectDescription?: string;
    eventDetails?: Record<string, unknown>;
  },
) => {
  const body = new FormData();

  body.append('eventType', event);

  if (params?.eventDetails) {
    try {
      const preparedData = JSON.stringify(params.eventDetails);
      body.append('eventDetails', preparedData);
    } catch (e) {}
  }
  if (params?.objectId) body.append('objectId', params.objectId);
  if (params?.objectDescription) body.append('objectDescription', params.objectDescription);

  const response = await fetch(createPath({ route: ERoutes.AuditSendEvent }), {
    method: 'POST',
    body,
  });
  if (!response.ok) throw Error(await response.json());
  return await response.json();
};

export const audit = {
  sendEvent,
};
