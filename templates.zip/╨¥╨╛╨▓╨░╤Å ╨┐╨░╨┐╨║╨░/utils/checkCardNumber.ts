/**
 * Алгоритм Луна
 * https://ru.wikipedia.org/wiki/%D0%90%D0%BB%D0%B3%D0%BE%D1%80%D0%B8%D1%82%D0%BC_%D0%9B%D1%83%D0%BD%D0%B0
 *
 * @param value - номер карты
 */
export const checkCardNumber = (value: string | number): boolean => {
  const cardNumbers: string[] = String(value).replace(/\D/g, '').split('');

  if (!cardNumbers.length) return false;

  const checkSum = (cardNumbers ?? []).reduce((acc, item, i) => {
    let digit = parseInt(item, 10);

    acc += i % 2 === 0 && 9 < (digit *= 2) ? digit - 9 : digit;

    return acc;
  }, 0);

  return checkSum % 10 === 0;
};
