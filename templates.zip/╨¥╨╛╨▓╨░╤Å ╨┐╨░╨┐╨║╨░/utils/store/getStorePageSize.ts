import { DEFAULT_PAGE_SIZE_OPTIONS } from '@pb/uikit';
import { EStoreKeys } from '~/shared/enums';
import { userSettingsStore } from '~/process/store';

const DEFAULT_PAGE_SIZE = DEFAULT_PAGE_SIZE_OPTIONS[1];

export async function getStorePageSize(request: Request, key?: EStoreKeys): Promise<number> {
  return await userSettingsStore.getItem<number>(
    request,
    key ?? EStoreKeys.PageSize,
    DEFAULT_PAGE_SIZE,
  );
}
