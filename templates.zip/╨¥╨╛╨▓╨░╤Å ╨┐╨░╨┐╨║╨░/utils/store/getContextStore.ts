import type { IStore, TStoreContext } from '@pb/store';
import { fetchApi } from '~/shared/api';

export function getContextStore(context: any, request: Request): Promise<IStore> {
  const { asyncStore } = context as TStoreContext;

  return asyncStore.getStore(fetchApi, request);
}
