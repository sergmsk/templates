import type { ELanguages } from '~/shared/enums';
import { EStoreKeys } from '~/shared/enums';
import { userSettingsStore } from '~/process/store';

export async function getStoreLanguage(request: Request): Promise<ELanguages> {
  return await userSettingsStore.getItem<ELanguages>(request, EStoreKeys.Language);
}
