import type { ZodObject, ZodRawShape } from 'zod';

import { userSettingsStore } from '~/process/store';

export type TGetStoreFiltersArgs = {
  request: Request;
  key: string;
  schema: ZodObject<ZodRawShape>;
};

export const getStoreFilters = async ({ request, key, schema }: TGetStoreFiltersArgs) => {
  try {
    const filtersString = await userSettingsStore.getItem(request, key);
    let resultSaveFilters = {};

    if (filtersString) {
      const filters = filtersString ? JSON.parse(filtersString) : {};
      const validateFilters = schema.safeParse(filters);

      if (validateFilters.success) {
        resultSaveFilters = filters;
      }
    }

    return resultSaveFilters;
  } catch(error) {
    console.log(error);
  }
};
