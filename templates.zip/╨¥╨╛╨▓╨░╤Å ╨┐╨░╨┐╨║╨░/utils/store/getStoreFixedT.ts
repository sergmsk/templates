import type { TFunction, InitOptions } from 'i18next';
import { remixI18next } from '~/services';
import { ERoutesToNameSpace } from '~/shared/enums';
import { getStoreLanguage, parseAcceptLanguage } from '~/utils';

const NAMESPACES = [
  'index',
  'errorBoundary',
  ERoutesToNameSpace.Users,
  ERoutesToNameSpace.Organizations,
  ERoutesToNameSpace.Projects,
  ERoutesToNameSpace.PaymentDetails,
  ERoutesToNameSpace.Graphs,
  ERoutesToNameSpace.Participants,
  ERoutesToNameSpace.Transactions,
  ERoutesToNameSpace.Addresses,
  ERoutesToNameSpace.Markup,
];

export async function getStoreFixedT(
  request: Request,
  namespaces: string | string[] = NAMESPACES,
  options?: Omit<InitOptions, 'react'>,
): Promise<TFunction> {
  const language = await getStoreLanguage(request);

  return remixI18next.getFixedT(language ?? parseAcceptLanguage(request), namespaces, options);
}
