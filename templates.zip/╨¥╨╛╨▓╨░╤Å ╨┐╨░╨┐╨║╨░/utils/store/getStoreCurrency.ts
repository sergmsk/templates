import { DEFAULT_CURRENCY } from '~/shared/constants';
import { EStoreKeys } from '~/shared/enums';
import { userSettingsStore } from '~/process/store';

export async function getStoreCurrency(request: Request) {
  return userSettingsStore.getItem(request, EStoreKeys.Currency, DEFAULT_CURRENCY);
}
