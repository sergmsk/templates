export type RequiredProps<T, K extends keyof T> = T & Required<Pick<T, K>>;

export type DeepPartial<T> = {
  [Prop in keyof T]?: Partial<T[Prop]>;
};
