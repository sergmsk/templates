export function isNumberGreaterThan(num1: number | string, num2: number | string): boolean {
  return Number(num1) > Number(num2);
}
