import dayjs from 'dayjs';
import type { Dayjs } from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
import { GRAPH_DATE_FORMAT, LOCALES } from '~/shared/constants';
import { ELanguages } from '~/shared/enums';
dayjs.extend(customParseFormat);
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.extend(utc);
dayjs.extend(timezone);

export function findLocaleForCurrentDate(date: Dayjs): string {
  return Object.values(ELanguages).filter((locale) => {
    return dayjs(date, GRAPH_DATE_FORMAT, locale, true).isValid();
  })[0];
}

export function formatDate(
  date: Dayjs,
  language: string = ELanguages.Ru,
  format = GRAPH_DATE_FORMAT,
): string {
  const locale = LOCALES[language];
  return dayjs(date).utc().locale(locale).format(format);
}

export function formatUtcDate(date: Dayjs): string {
  return dayjs(date).utc(true).format();
}

type shortCryptoAddressOptions = {
  dotAmount?: number;
  symbolAmount?: number;
};

export function formatToShortCryptoAddress(
  address: string,
  options?: shortCryptoAddressOptions,
): string {
  const { dotAmount = 4, symbolAmount = 6 } = options ?? {};
  const valueToFormat = address ?? '';

  return `${valueToFormat.slice(0, symbolAmount)} ${Array.from(
    new Array(dotAmount),
    () => '.',
  ).join('')} ${valueToFormat.slice(-symbolAmount)}`;
}

export function formatToFullName({
  firstName,
  lastName,
  middleName,
  separator = ' ',
  emptyValue = '-',
}: {
  firstName?: string | null;
  lastName?: string | null;
  middleName?: string | null;
  separator?: string;
  emptyValue?: string;
}): string {
  const fullName = [lastName, firstName, middleName].filter(Boolean);

  return fullName.length ? fullName.join(separator) : emptyValue;
}

export function formatToCapitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export const numberWithSpaces = (x: number) => {
  const parts = x.toString().split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  return parts.join('.');
};

export const formatView = (value?: string | number | null): string => {
  return typeof value === 'number' ? value.toString() : value ? value : '-';
};

export const formatArrayToMapById = <TItem extends { id: any }>(
  arr?: TItem[],
): Map<TItem['id'], TItem> =>
  (arr ?? []).reduce((acc, item) => {
    acc.set(item.id, item);

    return acc;
  }, new Map<TItem['id'], TItem>());

export const formatArrayToMap = (list: string[]) =>
  (list ?? []).reduce((acc, item) => ({ ...acc, [item]: true }), {});
