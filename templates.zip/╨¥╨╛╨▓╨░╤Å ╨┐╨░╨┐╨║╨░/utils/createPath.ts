import type { ParsedQs } from 'qs';
import { stringify } from 'qs';

import type { ERoutes } from '~/shared/enums';
import type { TObjUrlParams } from '~/types';

type TRoutes =
  | ERoutes.Addresses
  | ERoutes.AddressesResourcesGenerateFile
  | ERoutes.AlertRuleManagerResourcesCreateRule
  | ERoutes.AlertRuleManagerResourcesDeleteRule
  | ERoutes.Applications
  | ERoutes.AuditSendEvent
  | ERoutes.ConnectionsGraphLanding
  | ERoutes.GraphsResourcesSave
  | ERoutes.MarkupResourcesUploadMigrations
  | ERoutes.PaymentDetails
  | ERoutes.PaymentDetailsResourcesGetScreenshot
  | ERoutes.PaymentDetailsResourcesDelete
  | ERoutes.PaymentDetailsResourcesSearchCryptoTransactionOptions
  | ERoutes.PaymentDetailsResourcesVerificationInfo
  | ERoutes.PaymentDetailsResourcesXlsx
  | ERoutes.ParticipantsAddPrivatePerson
  | ERoutes.ParticipantsAdd
  | ERoutes.Organizations
  | ERoutes.OrganizationsAdd
  | ERoutes.UsersAdd
  | ERoutes.Graphs
  | ERoutes.ConnectionsGraph
  | ERoutes.Transactions
  | ERoutes.Participants
  | ERoutes.ParticipantResourcesGenerateFile
  | ERoutes.PaymentDetailsResourcesGenerateFile
  | ERoutes.ProjectsResourcesGenerateFile
  | ERoutes.ProjectsResourcesAddGraphsToProject
  | ERoutes.ProjectsResourcesCreateProject
  | ERoutes.ProjectsResourcesDeleteProject
  | ERoutes.ProjectsResourcesEditProject
  | ERoutes.ProjectsResourcesDeleteGraphsFromProject
  | ERoutes.TransactionsGraph
  | ERoutes.OrganizationsSearch
  | ERoutes.TransactionsTokensSearch
  | ERoutes.ResourcesBankById
  | ERoutes.ResourcesSearchAddresses
  | ERoutes.PaymentDetailsResourcesBanks
  | ERoutes.PaymentDetailsList
  | ERoutes.ResourcesSearchUsers
  | ERoutes.Settings
  | ERoutes.TransactionResourcesInputOutput
  | ERoutes.TransactionsResourcesGenerateFile
  | ERoutes.PaymentDetailsResourcesVerificationReport
  | ERoutes.ParticipantsResourcesDeleteParticipant
  | ERoutes.ParticipantsResourcesRestoreParticipant
  | ERoutes.ParticipantsResourcesSearchParticipants
  | ERoutes.ParticipantResourcesMarkupHistory
  | ERoutes.TagConflictsResourcesGetTagConflictById
  | ERoutes.TagConflictsResourcesTagConflictResolve
  | ERoutes.TagConflictsResourcesTagConflictByIdXlsx
  | ERoutes.TagConflictsResourcesTagConflictsXlsx
  | ERoutes.Review
  | ERoutes.MarkupConflicts
  | ERoutes.MarkupImport
  | ERoutes.MarkupResourcesMigrations
  | ERoutes.TagArtifactsResourcesSearchUserArtifacts
  | ERoutes.TagArtifactsResourcesCreateUserArtifacts
  | ERoutes.PermissionDenied
  | ERoutes.Projects
  | ERoutes.ProjectsResourcesGetGraphs
  | ERoutes.ProjectsResourcesGetProjectGroups
  | ERoutes.ProjectsResourcesAddProjectAccessToGroups
  | ERoutes.ProjectsResourcesDeleteProjectAccessFromGroups
  | ERoutes.PaymentDetailsResourcesBankByBin
  | ERoutes.ResourcesCurrencies
  | ERoutes.ResourcesGetGroupRoles
  | ERoutes.ResourcesSearch
  | ERoutes.ResourcesSearchCities
  | ERoutes.ResourcesSearchCountries
  | ERoutes.Login
  | ERoutes.Logout
  | ERoutes.Profile
  | ERoutes.Root
  | ERoutes.Users
  | ERoutes.UserEdit
  | ERoutes.PaymentDetailsResourcesTransactionMatchingXlsx
  | ERoutes.Search
  | ERoutes.SearchAddresses
  | ERoutes.SearchTransactions
  | ERoutes.SearchParticipants
  | ERoutes.FiatTransactions
  | ERoutes.ParticipantsResourceSearchParticipantsWithPagination
  | ERoutes.AddessResourcesUpdateMarkup
  | ERoutes.NotFound;

export type TRoutesWithParams =
  | ERoutes.GraphResourcesTraceCounterparties
  | ERoutes.GraphResourcesTraceMovements
  | ERoutes.TransactionsGraph
  | ERoutes.ConnectionsGraph
  | ERoutes.ConnectionsGraphLanding
  | ERoutes.TransactionDetail
  | ERoutes.AddressDetail
  | ERoutes.AddressMain
  | ERoutes.AddressMentions
  | ERoutes.AddressTransactions
  | ERoutes.AddressResourcesMarkup
  | ERoutes.AddressResourcesGetTagAddress
  | ERoutes.UserDetail
  | ERoutes.UserEdit
  | ERoutes.UserDisable
  | ERoutes.UserEnable
  | ERoutes.UserResetPassword
  | ERoutes.UserLogout
  | ERoutes.ParticipantDetail
  | ERoutes.ParticipantMain
  | ERoutes.ParticipantEdit
  | ERoutes.ParticipantsEditPrivatePerson
  | ERoutes.ParticipantsEditOrganization
  | ERoutes.ParticipantsEditResource
  | ERoutes.PaymentDetailsEdit
  | ERoutes.ParticipantPaymentDetails
  | ERoutes.ParticipantPaymentDetailsAdd
  | ERoutes.ClusterMain
  | ERoutes.ClusterDetail
  | ERoutes.ClusterAddresses
  | ERoutes.ClusterCounterparties
  | ERoutes.ClusterTransactions
  | ERoutes.AddressMarkupAdd
  | ERoutes.AddressMarkupEdit
  | ERoutes.AddressMarkupDelete
  | ERoutes.AddressResourcesCounterparties
  | ERoutes.AddressResourcesMentions
  | ERoutes.AddressResourcesMentionsCommand
  | ERoutes.AddressResourcesMentionsStatus
  | ERoutes.AddressResourcesTransactions
  | ERoutes.AddressResourcesSubscribe
  | ERoutes.ParticipantResourcesMarkupAdd
  | ERoutes.ParticipantsResourcesDetail
  | ERoutes.ParticipantsResourcesCounterparties
  | ERoutes.ParticipantResourcesMentions
  | ERoutes.AddressResourcesDetail
  | ERoutes.TransactionResourcesDetail
  | ERoutes.TransactionResourcesTransfers
  | ERoutes.AddressCounterparties
  | ERoutes.OrganizationDetail
  | ERoutes.OrganizationUsers
  | ERoutes.OrganizationEdit
  | ERoutes.OrganizationResourcesDelete
  | ERoutes.OrganizationResourcesRestore
  | ERoutes.ParticipantCounterparties
  | ERoutes.GraphResourcesParty
  | ERoutes.GraphResourcesPartyCounterparties
  | ERoutes.ParticipantAddresses
  | ERoutes.ParticipantMentions
  | ERoutes.ParticipantClusters
  | ERoutes.ParticipantTransactions
  | ERoutes.ParticipantMentionsAddresses
  | ERoutes.TransactionResourcesInputOutput
  | ERoutes.TransactionResourcesInputOutputV1
  | ERoutes.TransactionPdf
  | ERoutes.TransactionResourcesInputs
  | ERoutes.TransactionResourcesOutputs
  | ERoutes.AddressResourcesTokens
  | ERoutes.AddressResourcesTokensV2
  | ERoutes.AddressResourcesAddressWidget
  | ERoutes.ParticipantsAddType
  | ERoutes.AddressResourcesMarkupHistory
  | ERoutes.GraphResourcesAddressNodes
  | ERoutes.GraphResourcesTransactionNodes
  | ERoutes.PaymentDetailsEditAlertId
  | ERoutes.PaymentDetailsTransactionMatchingSearch
  | ERoutes.PaymentDetailsTransactionMatchingResult
  | ERoutes.PaymentDetailsTransactionMatchingSave
  | ERoutes.TransactionResourcesTransfersAll
  | ERoutes.TransactionResourcesTransfersV1
  | ERoutes.TransactionResourcesTransfersAllV1
  | ERoutes.TransactionResourcesContract
  | ERoutes.ProjectsDetail
  | ERoutes.GraphResourcesTokens
  | ERoutes.AddressTransactionsResourcesGenerateFile
  | ERoutes.AddressMentionsResourcesGenerateFile
  | ERoutes.AddressCounterpartiesResourcesGenerateFile
  | ERoutes.ParticipantsCounterpartiesResourcesGenerateFile
  | ERoutes.ParticipantsClustersResourcesGenerateFile
  | ERoutes.ParticipantsAddressesResourcesGenerateFile
  | ERoutes.ParticipantsTransactionsResourcesGenerateFile
  | ERoutes.ParticipantsMentionsResourcesGenerateFile
  | ERoutes.ParticipantsPaymentDetailsResourcesGenerateFile
  | ERoutes.Files
  | ERoutes.AnonParticipantDetail
  | ERoutes.PaymentDetailsResourcesGetPaymentDetailsById
  | ERoutes.Login;

type TCreatePathProps =
  | { route: TRoutes; withIndex?: boolean }
  | { route: TRoutesWithParams; withIndex?: boolean; params: Record<string, string | number> };

type TCreatePathPropsWithParams = Extract<TCreatePathProps, { route: any; params: any }>;

const ROUTER_PREFIX =
  // @ts-ignore
  typeof window !== 'undefined' ? window.ENV?.ROUTER_PREFIX : process.env?.ROUTER_PREFIX;

export function createPath(
  props: TCreatePathProps,
  query?: TObjUrlParams | URLSearchParams | ParsedQs,
): string {
  let path: string = props.route;

  if (props.withIndex) {
    path += '?index';
  }

  if (props.hasOwnProperty('params')) {
    path = Object.entries((props as TCreatePathPropsWithParams).params).reduce(
      (previousValue: string, [param, value]) => previousValue.replace(`:${param}`, String(value)),
      path,
    );
  }

  if (query) {
    const params =
      query instanceof URLSearchParams ? query.toString() : stringify(query, { encode: false });

    if (params) path = `${path}${path.includes('?') ? '&' : '?'}${params}`;
  }

  if (ROUTER_PREFIX) {
    path = ROUTER_PREFIX + path;
  }

  return path;
}
