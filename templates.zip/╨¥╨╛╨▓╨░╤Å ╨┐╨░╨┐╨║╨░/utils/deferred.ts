const noop = () => {};

export class Deferred<T = unknown> {
  private resolveFunction: (value: T) => void = noop;
  private rejectFunction: () => void = noop;

  get resolve() {
    return this.resolveFunction;
  }

  get reject() {
    return this.rejectFunction;
  }

  promise: Promise<T> = new Promise((resolve, reject) => {
    this.resolveFunction = resolve;
    this.rejectFunction = reject;
  });
}
