export const isFirefox = () => {
  const userAgent = window.navigator.userAgent;
  return userAgent.includes('Firefox');
};
